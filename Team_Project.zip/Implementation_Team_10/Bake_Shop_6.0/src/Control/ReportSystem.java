package Control;

import Model.AdvancedOrder;
import Model.Item;
import Model.Order;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Map;

public class ReportSystem {
    private static String selectedStore;

    public ReportSystem() {
    }

    /**
     * method name: calculateCoffee
     * description:
     * param: []
     * @return int
     */
    public static int calculateCoffee() {
        String storeID = selectedStore;
        ArrayList<Order> completedOrder = OrderDisplaySystem.getCompletedOrder(storeID);
        int coffee = 0;

        String date = getDate();
        for (int i = 0; i < completedOrder.size(); i++) {
            Order order = completedOrder.get(i);
            String orderDate = order.getDate().substring(0, 3) + order.getDate().substring(6);
            if (orderDate.equals(date)) {
                for (int j = 0; j < order.getItems().length; j++) {
                    String item = order.getItems()[j];
                    if (item.equalsIgnoreCase("ice coffee") || item.equalsIgnoreCase("Cappuccino") || item.equalsIgnoreCase("Expresso") || item.equalsIgnoreCase("Mocha") || item.equalsIgnoreCase("ice latte") || item.equalsIgnoreCase("double Expresso")) {
                        coffee = Integer.parseInt(coffee + order.getQuantity()[j]);
                    }
                }
            }

        }
        return coffee;
    }

    /**
     * method name: getDate
     * description:
     * param: []
     * @return java.lang.String
     */
    public static String getDate() {
        Date datetime = new Date();
        SimpleDateFormat dateForm = new SimpleDateFormat("MM/YYYY");

        Calendar cal = Calendar.getInstance();
        cal.setTime(datetime);
        cal.add(Calendar.MONTH, -1);
        String date = dateForm.format(cal.getTime());
        //System.out.println(date);
        return date;
    }

    /**
     * method name: calculateCoffeeBeans
     * description:
     * param: []
     * @return int
     */
    public static int calculateCoffeeBeans() {
        String storeID = selectedStore;
        ArrayList<AdvancedOrder> completedAdvancedOrder = OrderDisplaySystem.getCompletedAdvancedOrder(storeID);
        int coffeeBeans = 0;

        String date = getDate();
        for (int i = 0; i < completedAdvancedOrder.size(); i++) {
            AdvancedOrder advancedOrder = completedAdvancedOrder.get(i);
            String orderDate = advancedOrder.getDate().substring(0, 3) + advancedOrder.getDate().substring(6);
            //System.out.println(orderDate);
            if (orderDate.equals(date)) {
                for (int j = 0; j < advancedOrder.getItems().length; j++) {
                    String item = advancedOrder.getItems()[j];
                    if (item.equalsIgnoreCase("roast coffee beans")) {
                        coffeeBeans = Integer.parseInt(coffeeBeans + advancedOrder.getQuantity()[j]);
                    }
                }

            }
        }
        return coffeeBeans;
    }

    /**
     * method name: calculateFood
     * description:
     * param: []
     * @return int
     */
    public static int calculateFood() {
        String storeID = selectedStore;
        ArrayList<Order> completedOrder = OrderDisplaySystem.getCompletedOrder(storeID);
        int food = 0;

        String date = getDate();
        for (int i = 0; i < completedOrder.size(); i++) {
            Order order = completedOrder.get(i);
            String orderDate = order.getDate().substring(0, 3) + order.getDate().substring(6);
            if (orderDate.equals(date)) {
                for (int j = 0; j < order.getItems().length; j++) {
                    food = food + Integer.parseInt(order.getQuantity()[j]);
                }
            }

        }
        return food;
    }

    /**
     * method name: calculateCost
     * description:
     * param: []
     * @return int
     */
    public static int calculateCost() {
        int food = calculateFood();
        int beans = calculateCoffeeBeans();
        int totalCost = (food + beans) * 1;
        return totalCost;
    }

    /**
     * method name: calculateRevenue
     * description:
     * param: []
     * @return int
     */
    public static int calculateRevenue() {
        return (calculateTotalSale() - calculateCost());
    }

    /**
     * method name: calculateTotalSale
     * description:
     * param: []
     * @return int
     */
    public static int calculateTotalSale() {
        int sale = 0;
        String storeID = selectedStore;
        ArrayList<Order> completedOrder = OrderDisplaySystem.getCompletedOrder(storeID);
        ArrayList<AdvancedOrder> completedAdvancedOrder = OrderDisplaySystem.getCompletedAdvancedOrder(storeID);

        String date = getDate();
        for (int i = 0; i < completedOrder.size(); i++) {
            Order order = completedOrder.get(i);
            String orderDate = order.getDate().substring(0, 3) + order.getDate().substring(6);
            if (orderDate.equals(date)) {
                for (int j = 0; j < order.getItems().length; j++) {
                    sale = sale + Integer.parseInt(order.getQuantity()[j]) * Integer.parseInt(order.getPrice()[j]);
                }
            }

        }

        for (int i = 0; i < completedAdvancedOrder.size(); i++) {
            AdvancedOrder advancedOrder = completedAdvancedOrder.get(i);
            String orderDate = advancedOrder.getDate().substring(0, 3) + advancedOrder.getDate().substring(6);
            if (orderDate.equals(date)) {
                for (int j = 0; j < advancedOrder.getItems().length; j++) {
                    sale = sale + Integer.parseInt(advancedOrder.getQuantity()[j]) * Integer.parseInt(advancedOrder.getPrice()[j]);
                }
            }

        }
        return sale;

    }

    /**
     * method name: findMostSaleCoffe
     * description:
     * param: []
     * @return java.lang.String
     */
    public static String findMostSaleCoffe() {
        String storeID = selectedStore;
        ArrayList<Order> completedOrder = OrderDisplaySystem.getCompletedOrder(storeID);
        int iceCoffee = 0;
        int cappuccino = 0;
        int expresso = 0;
        int mocha = 0;
        int iceLatte = 0;
        int doubleExpresso = 0;

        String date = getDate();
        for (int i = 0; i < completedOrder.size(); i++) {
            Order order = completedOrder.get(i);
            String orderDate = order.getDate().substring(0, 3) + order.getDate().substring(6);
            if (orderDate.equals(date)) {
                for (int j = 0; j < order.getItems().length; j++) {
                    String item = order.getItems()[j];
                    if (item.equalsIgnoreCase("ice coffee")) {
                        iceCoffee++;
                    } else if (item.equalsIgnoreCase("Cappuccino")) {
                        cappuccino++;
                    } else if (item.equalsIgnoreCase("Expresso")) {
                        expresso++;
                    } else if (item.equalsIgnoreCase("Mocha")) {
                        mocha++;
                    } else if (item.equalsIgnoreCase("ice latte")) {
                        iceLatte++;
                    } else if (item.equalsIgnoreCase("double Expresso")) {
                        doubleExpresso++;
                    }

                }
            }

        }
        int[] mostCoffee = {iceCoffee, cappuccino, expresso, mocha, iceLatte, doubleExpresso};
        String[] coffeeType = {"ice coffee", "Cappuccino", "Expresso", "Mocha", "ice latte", "doubleExpresso"};
        String mostSaleCoffee = "";
        int mostSale = 0;
        for (int m = 0; m < mostCoffee.length; m++) {
            if (mostCoffee[m] > mostSale) {
                mostSale = mostCoffee[m];
                mostSaleCoffee = coffeeType[m];
            }
        }
        return mostSaleCoffee;
    }

    /**
     * method name: findMostSaleFood
     * description:
     * param: []
     * @return java.lang.String
     */
    public static String findMostSaleFood() {
        String storeID = selectedStore;
        ArrayList<Order> completedOrder = OrderDisplaySystem.getCompletedOrder(storeID);
        Map<Item, Integer> food = InventorySystem.searchItem();

        //get food sale
        ArrayList<Integer> saleList = new ArrayList<>();
        //get food names
        ArrayList<String> foodList = new ArrayList<>();
        for (Map.Entry<Item, Integer> entry : food.entrySet()) {
            String foodName = entry.getKey().getItemName();
            foodList.add(foodName);
            saleList.add(0);
        }

        String date = getDate();
        for (int i = 0; i < completedOrder.size(); i++) {
            Order order = completedOrder.get(i);
            String orderDate = order.getDate().substring(0, 3) + order.getDate().substring(6);
            if (orderDate.equals(date)) {
                for (int j = 0; j < order.getItems().length; j++) {
                    String item = order.getItems()[j];

                    int sale = 0;
                    for (int a = 0; a < foodList.size(); a++) {
                        if (foodList.get(a).equalsIgnoreCase(item)) {
                            sale++;
                            saleList.set(a, sale);
                        }
                    }

                }
            }

        }

        String mostSaleFood = "";
        int mostSale = 0;
        for (int b = 0; b < foodList.size(); b++) {
            if (saleList.get(b) > mostSale) {
                mostSale = saleList.get(b);
                mostSaleFood = foodList.get(b);
            }
        }
        //System.out.println(mostSaleFood);
        return mostSaleFood;
    }

    /**
     * method name: findDaySaleCoffee
     * description:
     * param: []
     * @return java.lang.String
     */
    public static String findDaySaleCoffee() {
        String coffee = findMostSaleCoffe();
        String storeID = selectedStore;
        ArrayList<Order> completedOrder = OrderDisplaySystem.getCompletedOrder(storeID);
        int mon = 0;
        int tue = 0;
        int wed = 0;
        int thu = 0;
        int fri = 0;
        int sat = 0;
        int sun = 0;


        String date = getDate();
        for (int i = 0; i < completedOrder.size(); i++) {
            Order order = completedOrder.get(i);
            String orderDate = order.getDate().substring(0, 3) + order.getDate().substring(6);

            if (orderDate.equals(date)) {
                for (int j = 0; j < order.getItems().length; j++) {
                    String item = order.getItems()[j];
                    if (item.equalsIgnoreCase(coffee)){
                        String dateTime = order.getDate();
                        String day = getDay(dateTime);
                        //System.out.println(day);
                        if (day.equalsIgnoreCase("Monday")) {
                            mon++;
                        } else if (day.equalsIgnoreCase("Tuesday")) {
                            tue++;
                        } else if (day.equalsIgnoreCase("Wednesday")) {
                            wed++;
                        } else if (day.equalsIgnoreCase("Thursday")) {
                            thu++;
                        } else if (day.equalsIgnoreCase("Friday")) {
                            fri++;
                        } else if (day.equalsIgnoreCase("Saturday")) {
                            sat++;
                        } else if (day.equalsIgnoreCase("Sunday")) {
                            sun++;
                        }
                    }


                }
            }

        }
        int[] saleList= {mon,tue,wed,thu,fri,sat,sun};
        String[] dayList = {"Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"};
        int mostSale = 0;
        String mostDay = "";
        for (int m = 0; m < dayList.length; m++) {
            if (saleList[m] > mostSale) {
                mostSale = saleList[m];
                mostDay = dayList[m];
            }
        }
        return mostDay;
    }

    /**
     * method name: findDaySaleFood
     * description:
     * param: []
     * @return java.lang.String
     */
    public static String findDaySaleFood() {
        String food= findMostSaleFood();
        String storeID = selectedStore;
        ArrayList<Order> completedOrder = OrderDisplaySystem.getCompletedOrder(storeID);
        int mon = 0;
        int tue = 0;
        int wed = 0;
        int thu = 0;
        int fri = 0;
        int sat = 0;
        int sun = 0;


        String date = getDate();
        for (int i = 0; i < completedOrder.size(); i++) {
            Order order = completedOrder.get(i);
            String orderDate = order.getDate().substring(0, 3) + order.getDate().substring(6);

            if (orderDate.equals(date)) {
                for (int j = 0; j < order.getItems().length; j++) {
                    String item = order.getItems()[j];
                    if (item.equalsIgnoreCase(food)){
                        String dateTime = order.getDate();
                        //System.out.println(dateTime);
                        String day = getDay(dateTime);
                        //System.out.println(day);
                        if (day.equalsIgnoreCase("Monday")) {
                            mon++;
                        } else if (day.equalsIgnoreCase("Tuesday")) {
                            tue++;
                        } else if (day.equalsIgnoreCase("Wednesday")) {
                            wed++;
                        } else if (day.equalsIgnoreCase("Thursday")) {
                            thu++;
                        } else if (day.equalsIgnoreCase("Friday")) {
                            fri++;
                        } else if (day.equalsIgnoreCase("Saturday")) {
                            sat++;
                        } else if (day.equalsIgnoreCase("Sunday")) {
                            sun++;
                        }
                    }


                }
            }

        }
        int[] saleList= {mon,tue,wed,thu,fri,sat,sun};
        String[] dayList = {"Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"};
        int mostSale = 0;
        String mostDay = "";
        for (int m = 0; m < dayList.length; m++) {
            if (saleList[m] > mostSale) {
                mostSale = saleList[m];
                mostDay = dayList[m];
            }
        }
        return mostDay;
    }

    /**
     * method name: getDay
     * description:
     * param: [date]
     * @return java.lang.String
     */
    public static String getDay(String date) {
        //change string into date
        SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy");
        Date dateTime = null;
        try {
            dateTime = format.parse(date);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        //System.out.println(format.format(dateTime));

        Calendar cal = Calendar.getInstance();
        cal.setTime(dateTime);
        String day = "";
        //System.out.println(cal.get(Calendar.DAY_OF_WEEK));
        if (cal.get(Calendar.DAY_OF_WEEK) == 2){
            day = "Monday";
        }else if (cal.get(Calendar.DAY_OF_WEEK) == 3){
            day = "Tuesday";
        }else if (cal.get(Calendar.DAY_OF_WEEK) == 4){
            day = "Wednesday";
        }else if (cal.get(Calendar.DAY_OF_WEEK) == 5){
            day = "Thursday";
        }else if (cal.get(Calendar.DAY_OF_WEEK) == 6){
            day = "Friday";
        }else if (cal.get(Calendar.DAY_OF_WEEK) == 7){
            day = "Saturday";
        }else if (cal.get(Calendar.DAY_OF_WEEK) == 1){
            day = "Sunday";
        }

        return day;
    }

    /**
     * method name: setSelectedStore
     * description:
     * param: [newSelected]
     * @return void
     */
    public static void setSelectedStore(String newSelected) {
        selectedStore = newSelected;
    }

    /**
     * method name: getSelectedStore
     * description:
     * param: []
     * @return java.lang.String
     */
    public static String getSelectedStore() {
        return selectedStore;
    }
}
