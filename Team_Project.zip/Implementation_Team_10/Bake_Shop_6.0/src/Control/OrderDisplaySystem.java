package Control;

import Model.AdvancedOrder;
import Model.Order;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.util.ArrayList;
import java.util.List;


public class OrderDisplaySystem {
    private static ArrayList<Order> readyOrderList = new ArrayList<>();
    private static ArrayList<Order> orderList = new ArrayList<>();
    private static ArrayList<AdvancedOrder> readyAdvancedOrderList = new ArrayList<>();
    private static ArrayList<AdvancedOrder> advancedOrderList = new ArrayList<>();

    public OrderDisplaySystem() {
    }

    /**
     * method name: readOrder
     * description:
     * param: []
     * @return void
     */
    public static void readOrder() {
        ArrayList<List> orderRawList = new ArrayList<>();
        try {
            // path
            File file = new File("src/Sample Data.xlsx");
            FileInputStream fis = new FileInputStream(file);
            XSSFWorkbook wb = new XSSFWorkbook(fis);
            // choose sheet
            XSSFSheet sheet = wb.getSheetAt(2);

            int rowTotalCount = sheet.getLastRowNum();
            int columnCount = sheet.getRow(0).getPhysicalNumberOfCells();

            for (int i = 0; i <= rowTotalCount; i++) {
                XSSFRow row = sheet.getRow(i);
                ArrayList<String> listRow = new ArrayList<>();
                for (int j = 0; j < columnCount; j++) {
                    String cell = null;

                    if (row.getCell(j) == null) {
                        cell = "";
                        listRow.add(cell);

                    } else {
                        Cell newCell = row.getCell(j);
                        switch (newCell.getCellType()) {
                            case STRING:
                                cell = newCell.getStringCellValue();
                                //System.out.print(cell.getStringCellValue() + "\t\t\t");
                                break;
                            case NUMERIC:    //field that represents number cell type
                                cell = "" + (int) newCell.getNumericCellValue();
                                //System.out.print(cell.getNumericCellValue() + "\t\t\t");
                                break;
                        }
                        listRow.add(cell);
                    }
                }
                orderRawList.add(listRow);
            }

        } catch (FileNotFoundException e) {
            System.out.println("Failed to find the file!");
        } catch (IOException e) {
            System.out.println("Failed to read the file");
        }

        orderRawList.remove(0);

        for (List list : orderRawList) {
            String[] itemList = list.get(3).toString().trim().split(" ,  ");
            String[] quantityList = list.get(4).toString().trim().split(", ");
            String[] priceList = list.get(5).toString().trim().replace("|"," ").split(" ");
            int totalAmount = 0;

            for (int i = 0; i < itemList.length; i++) {
                totalAmount += Integer.parseInt(priceList[i]);
            }

            Order order;
            AdvancedOrder advancedOrder;

            if (list.get(11).equals("")) {
                order = new Order(list.get(0).toString(), list.get(1).toString(), list.get(2).toString(), itemList,
                        quantityList, priceList, String.valueOf(totalAmount), list.get(7).toString(), list.get(8).toString(),
                        list.get(9).toString(), list.get(10).toString());
                readyOrderList.add(order);
            } else {
                advancedOrder = new AdvancedOrder(list.get(0).toString(), list.get(1).toString(), list.get(2).toString(), itemList,
                        quantityList, priceList, String.valueOf(totalAmount), list.get(7).toString(), list.get(8).toString(),
                        list.get(9).toString(), list.get(10).toString(), list.get(11).toString());
                readyAdvancedOrderList.add(advancedOrder);
            }
        }
    }

    /**
     * method name:
     * description:
     * param:
     * @return
     */
    public static void createOrder(String storeID, String orderID, String staffID, String[] items, String[] quantity,
                                   String[] price, String totalAmount, String date, String time, String custName,
                                   String orderStatus, String custPhone) {

        if (custPhone.equals("")) {
            Order order = new Order(storeID, orderID, staffID, items, quantity, price, totalAmount, date, time, custName, orderStatus);
            orderList.add(order);
            readyOrderList.add(order);
        } else {
            AdvancedOrder advOrder = new AdvancedOrder(storeID, orderID, staffID, items, quantity, price, totalAmount, date, time, custName, orderStatus, custPhone);
            advancedOrderList.add(advOrder);
            readyAdvancedOrderList.add(advOrder);
        }


    }

    /**
     * method name:
     * description:
     * param:
     * @return
     */
    public static String generateOrderID(){
        String orderID = "";
        int normalOrderID = Integer.parseInt(readyOrderList.get(readyOrderList.size() - 1).getOrderID());
        int adOrderID = Integer.parseInt(readyAdvancedOrderList.get(readyAdvancedOrderList.size() - 1).getOrderID());
        if (normalOrderID > adOrderID){
            orderID = normalOrderID + 1 + "";
        }else{
            orderID = adOrderID + 1 + "";
        }
        return orderID;
    }

    /**
     * method name:
     * description:
     * param:
     * @return
     */
    public static void writeOrder(String storeID,String orderID,String staffID,String items, String quantity, String price, String totalAmount, String date,String time,String custName,String orderStatus,String custPhone){
        try {
            // path
            File file = new File("src/Sample Data.xlsx");
            FileInputStream fis = new FileInputStream(file);
            XSSFWorkbook wb = new XSSFWorkbook(fis);
            // choose sheet
            XSSFSheet sheet = wb.getSheetAt(2);
            // create new row
            int currentLastRowIndex = sheet.getLastRowNum();
            int newRowIndex = currentLastRowIndex + 1;
            XSSFRow newRow = sheet.createRow(newRowIndex);
            // create cells
            int cellIndex = 0;

            XSSFCell newNameCell = newRow.createCell(cellIndex++);
            newNameCell.setCellValue(storeID);

            XSSFCell newEmailCell = newRow.createCell(cellIndex++);
            newEmailCell.setCellValue(orderID);

            XSSFCell newPasswordCell = newRow.createCell(cellIndex++);
            newPasswordCell.setCellValue(staffID);

            XSSFCell newAuthorityCell = newRow.createCell(cellIndex++);
            newAuthorityCell.setCellValue(items);

            XSSFCell newTFNCell = newRow.createCell(cellIndex++);
            newTFNCell.setCellValue(quantity);

            XSSFCell newAddressCell = newRow.createCell(cellIndex++);
            newAddressCell.setCellValue(price);

            XSSFCell newCityCell = newRow.createCell(cellIndex++);
            newCityCell.setCellValue(totalAmount);

            XSSFCell newStateCell = newRow.createCell(cellIndex++);
            newStateCell.setCellValue(date);

            XSSFCell newPostalCell = newRow.createCell(cellIndex++);
            newPostalCell.setCellValue(time);

            XSSFCell newPhoneCell = newRow.createCell(cellIndex++);
            newPhoneCell.setCellValue(custName);

            XSSFCell newStoreIDCell = newRow.createCell(cellIndex++);
            newStoreIDCell.setCellValue(orderStatus);

            XSSFCell neeStaffIDCell = newRow.createCell(cellIndex++);
            neeStaffIDCell.setCellValue(custPhone);


            FileOutputStream excelFileOutPutStream = new FileOutputStream("src/Sample Data.xlsx");
            wb.write(excelFileOutPutStream);
            excelFileOutPutStream.flush();
            excelFileOutPutStream.close();


        }catch (FileNotFoundException e) {
            System.out.println("Failed to find the file!");
        } catch (IOException e) {
            System.out.println("Failed to read the file");
        }

    }

    /**
     * method name: searchOrder
     * description:
     * param: [storeID]
     * @return java.util.ArrayList<Order>
     */
    public static ArrayList<Order> searchOrder(String storeID) {
        ArrayList<Order> foundOrder = new ArrayList<>();

        for (Order order : orderList) {
            if (order.getStoreID().equals(storeID)) {
                foundOrder.add(order);
            }
        }
        return foundOrder;
    }

    /**
     * method name: searchAdvancedOrder
     * description:
     * param: [storeID]
     * @return java.util.ArrayList<AdvancedOrder>
     */
    public static ArrayList<AdvancedOrder> searchAdvancedOrder(String storeID){
        ArrayList<AdvancedOrder> foundAdvancedOrder = new ArrayList<>();
        for (AdvancedOrder advancedOrder: advancedOrderList){
            if (advancedOrder.getStoreID().equals(storeID)){
                foundAdvancedOrder.add(advancedOrder);
            }
        }
        return foundAdvancedOrder;
    }

    /**
     * method name: searchReadyOrder
     * description:
     * param: [storeID]
     * @return java.util.ArrayList<Order>
     */
    public static ArrayList<Order> searchReadyOrder(String storeID) {
        ArrayList<Order> foundOrder = new ArrayList<>();

        for (Order order : orderList) {
            if (order.getStoreID().equals(storeID)) {
                foundOrder.add(order);
            }
        }
        return foundOrder;
    }

    /**
     * method name: searchReadyAdvancedOrder
     * description:
     * param: [storeID]
     * @return java.util.ArrayList<AdvancedOrder>
     */
    public static ArrayList<AdvancedOrder> searchReadyAdvancedOrder(String storeID){
        ArrayList<AdvancedOrder> foundAdvancedOrder = new ArrayList<>();
        for (AdvancedOrder advancedOrder: advancedOrderList){
            if (advancedOrder.getStoreID().equals(storeID)){
                foundAdvancedOrder.add(advancedOrder);
            }
        }
        return foundAdvancedOrder;
    }

    /**
     * method name: getReadyOrderList
     * description:
     * param: []
     * @return java.lang.String
     */
    public static String getReadyOrderList() {
        String displayContent = "";

        for (int i = 0; i < readyOrderList.size(); i++) {
            Order order = readyOrderList.get(i);
            String content = "";

            for (int j = 0; j < order.getItems().length; j++) {
                content = content + " " + order.getItems()[j] + "  x" + order.getQuantity()[j] +
                        "  price:" + order.getPrice()[j] + "$" + "\n";
            }

            displayContent += "\n" + " Order ID: " + order.getOrderID() + "\n" + " Staff ID: " + order.getStaffID() + "\n" + content
                    + " Total Price: " + order.getTotalAmount() + "\n" + " Date: " + order.getDate() + "\n"
                    + " Time: " + order.getTime() + "\n" + " Customer Name: " + order.getCustName() + " *** Normal Order *** " + "\n\n\n";
        }
        return displayContent;
    }

    /**
     * method name: getReadyAdOrderList
     * description:
     * param: []
     * @return java.lang.String
     */
    public static String getReadyAdOrderList() {
        String displayContent = "";

        for (int i = 0; i < readyAdvancedOrderList.size(); i++) {
            AdvancedOrder advancedOrder = readyAdvancedOrderList.get(i);
            String content = "";
            for (int j = 0; j < advancedOrder.getItems().length; j++) {
                content = content + " " + advancedOrder.getItems()[j] + "  x" + advancedOrder.getQuantity()[j] +
                        "  price:" + advancedOrder.getPrice()[j] + "$" + "\n";
            }

            displayContent += "\n" + " Order ID: " + advancedOrder.getOrderID() + "\n" + " Staff ID: " + advancedOrder.getStaffID() + "\n" + content
                    + " Total Price: " + advancedOrder.getTotalAmount() + "\n" + " Date: " + advancedOrder.getDate() + "\n"
                    + " Time: " + advancedOrder.getTime() + "\n" + " Customer Name: " + advancedOrder.getCustName() + "\n"
                    + " Customer Phone: " + advancedOrder.getCustPhone() + "\n" + " *** Advanced Order *** " + "\n\n\n";
        }
        return displayContent;
    }

    /**
     * method name: getCompletedOrder
     * description:
     * param: [storeID]
     * @return java.util.ArrayList<Order>
     */
    public static ArrayList<Order> getCompletedOrder(String storeID){
        ArrayList<Order> completedOrder = new ArrayList<>();
        for (int i = 0; i < readyOrderList.size(); i++) {
            Order order = readyOrderList.get(i);
            if(order.getStoreID().equals(storeID)){
                completedOrder.add(order);
            }
        }
        return completedOrder;
    }

    /**
     * method name: getCompletedAdvancedOrder
     * description:
     * param: [storeID]
     * @return java.util.ArrayList<AdvancedOrder>
     */
    public static ArrayList<AdvancedOrder> getCompletedAdvancedOrder(String storeID){
        ArrayList<AdvancedOrder> completedOrder = new ArrayList<>();
        for (int i = 0; i < readyAdvancedOrderList.size(); i++) {
            AdvancedOrder advancedorder = readyAdvancedOrderList.get(i);
            if(advancedorder.getStoreID().equals(storeID)){
                completedOrder.add(advancedorder);
            }
        }
        return completedOrder;
    }

    public void modifyStatus() {

    }

    public void displayCompleteError() {

    }

    public void deleteOrder() {

    }
}
