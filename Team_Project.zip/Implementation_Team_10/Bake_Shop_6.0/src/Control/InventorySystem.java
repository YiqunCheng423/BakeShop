package Control;

import Model.Item;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class InventorySystem {
    private static Map<Item, Integer> mapOfItems = new HashMap<>();  // initialize it to avoid nullException

    /**
     * method name: InventorySystem
     * description:
     * param: []
     * @return
     */
    public InventorySystem() {

    }

    /**
     * method name: readInventory
     * description:
     * param: []
     * @return void
     */
    public static void readInventory() {

        ArrayList<List> alist = new ArrayList<List>();
        try {
            // path
            File file = new File("src/Sample Data.xlsx");
            FileInputStream fis = new FileInputStream(file);
            XSSFWorkbook wb = new XSSFWorkbook(fis);
            // choose sheet
            XSSFSheet sheet = wb.getSheetAt(3);

            int rowTotalCount = sheet.getLastRowNum();
            int columnCount = sheet.getRow(0).getPhysicalNumberOfCells();


            for (int i = 0; i <= rowTotalCount; i++) {
                XSSFRow row = sheet.getRow(i);
                ArrayList<String> listRow = new ArrayList<String>();
                for (int j = 0; j < columnCount; j++) {

                    String cell = null;

                    if(row.getCell(j) == null){

                        cell = row.getCell(j)+"";

                        listRow.add(cell);

                    }else{
                        Cell newCell = row.getCell(j);
                        switch (newCell.getCellType()) {
                            case STRING:
                                cell = newCell.getStringCellValue();
                                //System.out.print(cell.getStringCellValue() + "\t\t\t");
                                break;
                            case NUMERIC:    //field that represents number cell type
                                cell = "" + (int)newCell.getNumericCellValue();
                                //System.out.print(cell.getNumericCellValue() + "\t\t\t");
                                break;
                        }

                        listRow.add(cell);
                    }


                }
                alist.add(listRow);


            }



        } catch (FileNotFoundException e) {
            System.out.println("Failed to find the file!");
        } catch (IOException e) {
            System.out.println("Failed to read the file");
        }

        // create item objects
        alist.remove(0);
        for (List list : alist){
            int amount = 0;

            String[] idCollection = list.get(0).toString().trim().replace("|"," ").split(" ");
            for (int m =0; m<idCollection.length; m++){
                String nameOfItem = list.get(2).toString().trim().replace("  "," ");
                //System.out.println(nameOfItem);
                HashMap<String, Float> itemOfOneStore = new HashMap<>();
                if (!(readOrder(idCollection[m]).isEmpty())) {
                    itemOfOneStore = readOrder(idCollection[m]);
                    //System.out.println(itemOfOneStore);
                }
                //System.out.println(nameOfItem + itemOfOneStore.get(nameOfItem));
                if(itemOfOneStore.get(nameOfItem) == null){
                    itemOfOneStore.put(nameOfItem,0.00f);
                }
                float priceOfItem = itemOfOneStore.get(nameOfItem);
                Item aitem = new Item(idCollection[m], list.get(1).toString(),nameOfItem,priceOfItem);
                //System.out.println(aitem.toString());
                amount = Integer.parseInt(list.get(3).toString());
                //System.out.println(amount);
                mapOfItems.put(aitem,amount);

            }

        }

    }


    /**
     * method name: searchItem
     * description:
     * param: []
     * @return java.util.Map<Item,java.lang.Integer>
     */ public static Map<Item, Integer> searchItem() {
        Map<Item, Integer> newMap = new HashMap<>();

        for (Map.Entry<Item, Integer> entry : mapOfItems.entrySet()) {
            String itemStore = entry.getKey().getStoreID();
            if (itemStore.equals(BakeShopSystem.getStoreID())) {
                newMap.put(entry.getKey(), entry.getValue());
            }
        }

        return newMap;
    }


    /**
     * method name: readOrder
     * description:
     * param: [storeID]
     * @return java.util.HashMap<java.lang.String,java.lang.Float>
     */
    public static HashMap<String, Float> readOrder(String storeID) {
        ArrayList<List> alist = new ArrayList<List>();

        try {
            // path
            File file = new File("src/Sample Data.xlsx");
            FileInputStream fis = new FileInputStream(file);
            XSSFWorkbook wb = new XSSFWorkbook(fis);
            // choose sheet
            XSSFSheet sheet = wb.getSheetAt(2);

            int rowTotalCount = sheet.getLastRowNum();
            int columnCount = sheet.getRow(0).getPhysicalNumberOfCells();

            for (int i = 0; i <= rowTotalCount; i++) {
                XSSFRow row = sheet.getRow(i);
                ArrayList<String> listRow = new ArrayList<String>();
                for (int j = 0; j < columnCount; j++) {
                    String cell = null;

                    if (row.getCell(j) == null) {
                        cell = row.getCell(j) + "";
                        listRow.add(cell);

                    } else {
                        Cell newCell = row.getCell(j);
                        switch (newCell.getCellType()) {
                            case STRING:
                                cell = newCell.getStringCellValue();
                                //System.out.print(cell.getStringCellValue() + "\t\t\t");
                                break;
                            case NUMERIC:    //field that represents number cell type
                                cell = "" + (int) newCell.getNumericCellValue();
                                //System.out.print(cell.getNumericCellValue() + "\t\t\t");
                                break;
                        }
                        listRow.add(cell);
                    }
                }
                alist.add(listRow);
            }

        } catch (FileNotFoundException e) {
            System.out.println("Failed to find the file!");
        } catch (IOException e) {
            System.out.println("Failed to read the file");
        }

        HashMap<String, Float> mapOfPrice = new HashMap<>();
        for (List list : alist) {
            mapOfPrice.putAll(readItemPrice(storeID, list));
        }
        //System.out.println(mapOfPrice.toString());
        return mapOfPrice;

    }

    /**
     * method name: readItemPrice
     * description:
     * param: [storeNumber, list]
     * @return java.util.HashMap<java.lang.String,java.lang.Float>
     */
    public static HashMap<String, Float> readItemPrice(String storeNumber, List list){
        HashMap<String, Float> mapOfPrice = new HashMap<>();

        if (list.get(0).toString().equals(storeNumber)) {
            String[] itemList = list.get(3).toString().replace(",  ",",").split(",");
            ArrayList<String> newItemList = new ArrayList<String>();
            for (int j= 0;j< itemList.length;j++){
                newItemList.add(itemList[j].substring(0,itemList[j].length()-1).replace("  "," ").trim());
                //System.out.println(newItemList.toString());
            }

            String[] quantityList = list.get(4).toString().trim().split(", ");
            String[] priceList = list.get(5).toString().trim().replace("|"," ").split(" ");

            for (int i = 0; i < newItemList.size(); i++) {
                float itemPrices = Float.parseFloat(priceList[i]) / Float.parseFloat(quantityList[i]);
                DecimalFormat decimalFormat=new DecimalFormat(".00");
                float itemPrice = Float.parseFloat(decimalFormat.format(itemPrices));
                //System.out.println(newItemList.get(i) +": "+ itemPrice);
                mapOfPrice.put(newItemList.get(i),itemPrice);
            }

        }
        //System.out.println(mapOfPrice.toString());
        return mapOfPrice;
    }

    public Map<Item, Integer> getInformation()
    {
        return null;
    }

    public Map<Item, Integer> checkLowInventory()
    {
        return null;
    }

    public boolean validateAddedInventoryNumber(int addedInventoryNumber)
    {
        return false;
    }

    /**
     * method name: addInventory
     * description:
     * param: [itemName, itemNumber]
     * @return void
     */
    public static void addInventory(String itemName, int itemNumber) {
        for (Map.Entry<Item, Integer> entry : mapOfItems.entrySet()) {
            String name = entry.getKey().getItemName();
            if (name.equals(itemName)) {
                mapOfItems.put(entry.getKey(), itemNumber + entry.getValue());
            }
        }
    }

    /**
     * method name: getMapOfItems
     * description:
     * param: []
     * @return java.util.Map<Item,java.lang.Integer>
     */
    public static Map<Item, Integer> getMapOfItems() {
        return mapOfItems;
    }

}
