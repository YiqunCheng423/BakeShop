package Control;

public class SettingSystem {
    public SettingSystem() {
    }

    public boolean validateAuthority() {
        return true;
    }

    public boolean validateStoreID() {
        return true;
    }

    public void changeStoreProcess() {}

    public boolean validateStaffID() {
        return true;
    }

    public boolean validateUsername(String username) {
        return true;
    }

    public boolean validatePassword(String password) {
        return true;
    }

    public boolean validatePhone(String phoneNumber) {
        return true;
    }

    public boolean validateCity(String city) {
        return true;
    }

    public boolean validatePostal(String postal) {
        return true;
    }

    public boolean validateEmail(String email) {
        return true;
    }

    public boolean validateTFN(String TFN) {
        return true;
    }

    public boolean validateStreet(String street) {
        return true;
    }

    public boolean validateState(String state) {
        return true;
    }

    public void setStaffDetails(int index) {}

    public void updateStaffDetails(String[] details) {

    }
}
