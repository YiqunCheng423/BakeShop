package Control;

import Model.Employee;
import Model.Item;

import java.util.ArrayList;
import java.util.Map;


public class BakeShopSystem {
    private static String userIDOrEmail;
    private static String storeID;



    /**
     * method name: BakeShopSystem
     * description:
     * param: []
     * @return
     */
    public BakeShopSystem() {
    }

    /**
     * method name: getUserIDOrEmail
     * description:
     * param: []
     * @return java.lang.String
     */
    public static String getUserIDOrEmail() {
        return userIDOrEmail;
    }

    /**
     * method name: setUserIDOrEmail
     * description:
     * param: [userIDOrEmail]
     * @return void
     */
    public static void setUserIDOrEmail(String userIDOrEmail) {
        BakeShopSystem.userIDOrEmail = userIDOrEmail;
    }

    /**
     * method name: checkItemNumber
     * description:
     * param: [itemName]
     * @return java.lang.String
     */
    public static String checkItemNumber(String itemName) {
        Map<Item, Integer> mapOfItems = InventorySystem.getMapOfItems();
        for (Item key: mapOfItems.keySet()){
            if (itemName.equalsIgnoreCase(key.getItemName())){
                return key.getItemNumber();
            }
        }
        return null;
    }


    /**
     * method name: checkItemPrice
     * description:
     * param: [itemName]
     * @return int
     */
    public static int checkItemPrice(String itemName) {
        Map<Item, Integer> mapOfItems = InventorySystem.getMapOfItems();

        for (Item key: mapOfItems.keySet()){
            if (itemName.equalsIgnoreCase(key.getItemName())){
                return mapOfItems.get(key);
            }
        }
        return 0;

    }


    /**
     * method name: getTotalPrice
     * description:
     * param: [items]
     * @return int
     */
    public static int getTotalPrice(ArrayList<String> items) {
        int totalPrice = 0;
        for (String item : items) {
            totalPrice += checkItemPrice(item);
        }
        return totalPrice;
    }

    /**
     * method name: getStoreID
     * description:
     * param: []
     * @return java.lang.String
     */
    public static String getStoreID() {
        return storeID;
    }

    /**
     * method name: setStoreID
     * description:
     * param: [storeID]
     * @return void
     */
    public static void setStoreID(String storeID) {
        BakeShopSystem.storeID = storeID;
    }

    /**
     * method name: getStaffID
     * description:
     * param: []
     * @return java.lang.String
     */
    public static String getStaffID() {
        ArrayList<Employee> listOfEmployee = RegistrationSystem.getListOfEmployee();

        for (Employee employee : listOfEmployee) {
            if(userIDOrEmail.equals(employee.getStaffID()) || userIDOrEmail.equals(employee.getEmail())) {
                return employee.getStaffID();
            }
        }
        return null;
    }

    /**
     * method name: checkStoreID
     * description:
     * param: [userIDOrEmail]
     * @return java.lang.String
     */
    public static String checkStoreID(String userIDOrEmail) {
        ArrayList<Employee> listOfEmployee = RegistrationSystem.getListOfEmployee();

        for (Employee employee : listOfEmployee) {
            if(userIDOrEmail.equals(employee.getStoreID()) || userIDOrEmail.equals(employee.getEmail())) {
                return employee.getStoreID();
            }
        }
        return null;
    }

    /**
     * method name: validateItemNumber
     * description:
     * param: [itemNumber]
     * @return boolean
     */
    public boolean validateItemNumber(int itemNumber)
    {
        return true;
    }

    /**
     * method name: validateRemoveNumber
     * description:
     * param: [removeNumber]
     * @return boolean
     */
    public boolean validateRemoveNumber(int removeNumber)
    {
        return true;
    }

    /**
     * method name: validateCustName
     * description:
     * param: [custName]
     * @return boolean
     */
    public boolean validateCustName(String custName)
    {
        return true;
    }

    /**
     * method name: validateCustPhone
     * description:
     * param: [custPhone]
     * @return boolean
     */
    public boolean validateCustPhone(String custPhone)
    {
        return true;
    }

    /**
     * method name: addOrderProcess
     * description:
     * param: [orderProcess]
     * @return void
     */
    public void addOrderProcess(Map<Item, Integer> orderProcess)
    {

    }
}
