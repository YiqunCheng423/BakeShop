package Control;

import Model.*;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class RegistrationSystem {
    private static ArrayList<Employee> listOfEmployee = new ArrayList<Employee>();

    public RegistrationSystem() {
    }

    /**
     * method name: getListOfEmployee
     * description:
     * param: []
     * @return java.util.ArrayList<Employee>
     */
    public static ArrayList<Employee> getListOfEmployee() {
        return listOfEmployee;
    }

    /**
     * method name: setListOfEmployee
     * description:
     * param: [list]
     * @return void
     */
    public static void setListOfEmployee(ArrayList<Employee> list) {
        listOfEmployee = list;
    }

    public String enterUsername() {
        return null;
    }

    public String enterPassword() {
        return null;
    }

    public String enterPhone() {
        return null;
    }

    public String enterCity() {
        return null;
    }

    public String enterPostal() {
        return null;
    }

    public String enterEmail() {
        return null;
    }

    public String enterTFN() {
        return null;
    }

    public String enterStreet() {
        return null;
    }

    public String enterState() {
        return null;
    }

    public String enterStoreId() {
        return null;
    }

    public void displayRegistrationError() {

    }

    /**
     * method name: readStaff
     * description:
     * param: []
     * @return void
     */
    public static void readStaff() {
        ArrayList<List> alist = new ArrayList<List>();
        try {
            // path
            File file = new File("src/Sample Data.xlsx");
            FileInputStream fis = new FileInputStream(file);
            XSSFWorkbook wb = new XSSFWorkbook(fis);
            // choose sheet
            XSSFSheet sheet = wb.getSheetAt(0);

            int rowTotalCount = sheet.getLastRowNum();
            int columnCount = sheet.getRow(0).getPhysicalNumberOfCells();

            for (int i = 0; i <= rowTotalCount; i++) {
                XSSFRow row = sheet.getRow(i);
                ArrayList<String> listRow = new ArrayList<String>();
                for (int j = 0; j < columnCount; j++) {

                    String cell = null;

                    if (row.getCell(j) == null) {

                        cell = row.getCell(j) + "";

                        listRow.add(cell);

                    } else {
                        Cell newCell = row.getCell(j);
                        switch (newCell.getCellType()) {
                            case STRING:
                                cell = newCell.getStringCellValue();
                                //System.out.print(cell.getStringCellValue() + "\t\t\t");
                                break;
                            case NUMERIC:    //field that represents number cell type
                                cell = "" + (int) newCell.getNumericCellValue();
                                //System.out.print(cell.getNumericCellValue() + "\t\t\t");
                                break;
                        }
                        listRow.add(cell);
                    }
                }
                alist.add(listRow);
                wb.close();

            }

        } catch (FileNotFoundException e) {
            System.out.println("Failed to find the file!");
        } catch (IOException e) {
            System.out.println("Failed to read the file");
        }
        for (List list : alist) {
            // create object
            if (list.get(4).toString().equals("Staff")){
                Staff staff = new Staff(list.get(0).toString(),list.get(1).toString(),list.get(2).toString(),list.get(3).toString(),list.get(5).toString(),list.get(6).toString(),list.get(7).toString(),list.get(8).toString(),list.get(9).toString(),list.get(10).toString(),list.get(11).toString(),"Staff");
                //System.out.println(staff.toString());
                listOfEmployee.add(staff);
            }else if(list.get(4).toString().equals("Manager")){
                Manager manager = new Manager(list.get(0).toString(), list.get(1).toString(), list.get(2).toString(), list.get(3).toString(), list.get(5).toString(), list.get(6).toString(), list.get(7).toString(), list.get(8).toString(), list.get(9).toString(), list.get(10).toString(), list.get(11).toString(), "Manager");
                //System.out.println(manager.toString());
                listOfEmployee.add(manager);
            }else if(list.get(4).toString().equals("Owner")){
                Owner owner = new Owner(list.get(0).toString(), list.get(1).toString(), list.get(2).toString(), list.get(3).toString(), list.get(5).toString(), list.get(6).toString(), list.get(7).toString(), list.get(8).toString(), list.get(9).toString(), list.get(10).toString(), list.get(11).toString(), "Owner");
                //System.out.println(owner.toString());
                listOfEmployee.add(owner);
            }

        }
    }

    /**
     * method name: writeStaff
     * description:
     * param: [staffID, name, email, password, authority, TFN, address, city, state, postal, phone, storeID]
     * @return void
     */
    public static void writeStaff(String staffID,String name,String email,String password, String authority, String TFN, String address, String city,String state,String postal,String phone,String storeID){
        try {
            // path
            File file = new File("src/Sample Data.xlsx");
            FileInputStream fis = new FileInputStream(file);
            XSSFWorkbook wb = new XSSFWorkbook(fis);
            // choose sheet
            XSSFSheet sheet = wb.getSheetAt(0);
            // create new row
            int currentLastRowIndex = sheet.getLastRowNum();
            int newRowIndex = currentLastRowIndex + 1;
            XSSFRow newRow = sheet.createRow(newRowIndex);
            // create cells
            int cellIndex = 0;
            XSSFCell neeStaffIDCell = newRow.createCell(cellIndex++);
            neeStaffIDCell.setCellValue(staffID);

            XSSFCell newNameCell = newRow.createCell(cellIndex++);
            newNameCell.setCellValue(name);

            XSSFCell newEmailCell = newRow.createCell(cellIndex++);
            newEmailCell.setCellValue(email);

            XSSFCell newPasswordCell = newRow.createCell(cellIndex++);
            newPasswordCell.setCellValue(password);

            XSSFCell newAuthorityCell = newRow.createCell(cellIndex++);
            newAuthorityCell.setCellValue(authority);

            XSSFCell newTFNCell = newRow.createCell(cellIndex++);
            newTFNCell.setCellValue(TFN);

            XSSFCell newAddressCell = newRow.createCell(cellIndex++);
            newAddressCell.setCellValue(address);

            XSSFCell newCityCell = newRow.createCell(cellIndex++);
            newCityCell.setCellValue(city);

            XSSFCell newStateCell = newRow.createCell(cellIndex++);
            newStateCell.setCellValue(state);

            XSSFCell newPostalCell = newRow.createCell(cellIndex++);
            newPostalCell.setCellValue(postal);

            XSSFCell newPhoneCell = newRow.createCell(cellIndex++);
            newPhoneCell.setCellValue(phone);

            XSSFCell newStoreIDCell = newRow.createCell(cellIndex++);
            newStoreIDCell.setCellValue(storeID);

            FileOutputStream excelFileOutPutStream = new FileOutputStream("src/Sample Data.xlsx");
            wb.write(excelFileOutPutStream);
            excelFileOutPutStream.flush();
            excelFileOutPutStream.close();


        }catch (FileNotFoundException e) {
            System.out.println("Failed to find the file!");
        } catch (IOException e) {
            System.out.println("Failed to read the file");
        }

    }

    /**
     * method name: createNewEmployee
     * description:
     * param: [name, email, password, TFN, street, city, state, postal, phone, storeID, authority]
     * @return java.lang.String
     */
    public static String createNewEmployee(String name, String email, String password, String TFN, String street, String city, String state, String postal, String phone, String storeID, String authority){
        String staffID = (Integer.parseInt(listOfEmployee.get(listOfEmployee.size() - 1).getStaffID())) + 1 + "";
        if (authority.equals("Owner")){
            Owner newOwner = new Owner(staffID,name,email,password,TFN,street,city,state,postal,phone,storeID,authority);
            listOfEmployee.add(newOwner);

        }else if (authority.equals("Staff")){
            Staff newStaff = new Staff(staffID,name,email,password,TFN,street,city,state,postal,phone,storeID,authority);
            listOfEmployee.add(newStaff);
        }else if (authority.equals("Manager")){
            Manager newManager = new Manager(staffID,name,email,password,TFN,street,city,state,postal,phone,storeID,authority);
            listOfEmployee.add(newManager);
        }

        return staffID;

    }

}
