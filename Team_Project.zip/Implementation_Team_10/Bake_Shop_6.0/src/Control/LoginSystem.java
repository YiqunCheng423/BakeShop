package Control;

import Model.Employee;
import Model.Store;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

public class LoginSystem {
    private static ArrayList<Store> listOfStore = new ArrayList<Store>();

    public LoginSystem() {
        readStore();
    }

    public static ArrayList<Store> getListOfStore() {
        return listOfStore;
    }

    public static void setListOfStore(ArrayList<Store> list) {
        listOfStore = list;
    }

    public void setStoreToBakeShopSystem(Store store) {
        listOfStore.add(store);
    }

    public Store getStoreFromBakeShopSystem(int index) {
        return listOfStore.get(index);
    }


    /**
     * method name: validateUserIDOrEmail
     * description:
     * param: [userIDOrEmail]
     * @return boolean
     */public static boolean validateUserIDOrEmail(String userIDOrEmail) {
        ArrayList<Employee> listOfEmployee = RegistrationSystem.getListOfEmployee();

        for (Employee employee : listOfEmployee) {
            if (userIDOrEmail.equals(employee.getStaffID()) || userIDOrEmail.equals(employee.getEmail())) {
                return true;
            }
        }
        return false;
    }

    /**
     * method name: validatePassword
     * description:
     * param: [userIDOrEmail, password]
     * @return boolean
     */
    public static boolean validatePassword(String userIDOrEmail, String password) {
        ArrayList<Employee> listOfEmployee = RegistrationSystem.getListOfEmployee();

        for (Employee employee : listOfEmployee) {
            if(userIDOrEmail.equals(employee.getStaffID()) || userIDOrEmail.equals(employee.getEmail())) {
                if (password.equals(employee.getPassword())){
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * method name:
     * description:
     * param:
     * @return
     */
    public static String getStoreID(String userIDOrEmail) {
        ArrayList<Employee> listOfEmployee = RegistrationSystem.getListOfEmployee();

        for (Employee employee : listOfEmployee) {
            if(userIDOrEmail.equals(employee.getStaffID()) || userIDOrEmail.equals(employee.getEmail())) {
                return employee.getStaffID();
            }
        }
        return null;
    }

    /**
     * method name:
     * description:
     * param:
     * @return
     */
    public static void readStore() {
        try {
            File file = new File("src/Sample Data.xlsx");
            FileInputStream fis = new FileInputStream(file);
            XSSFWorkbook wb = new XSSFWorkbook(fis);
            XSSFSheet sheet = wb.getSheetAt(1);

            for (Row row : sheet) {
                Iterator<Cell> cellIterator = row.cellIterator();
                int col = 0;
                String[] storeInformation = new String[]{"a", "b", "c", "d", "e", "f"};
                while (cellIterator.hasNext()) {


                    Cell cell = cellIterator.next();
                    switch (cell.getCellType()) {
                        case STRING:
                            storeInformation[col] = cell.getStringCellValue();
                            //System.out.print(cell.getStringCellValue() + "\t\t\t");
                            break;
                        case NUMERIC:    //field that represents number cell type
                            storeInformation[col] = "" + (int) cell.getNumericCellValue();
                            //System.out.print(cell.getNumericCellValue() + "\t\t\t");
                            break;
                    }
                    col++;
                }

                if (!storeInformation[5].equals("Contact number") && !storeInformation[5].equals("f")) {
                    Store e = new Store(storeInformation[0], storeInformation[1], storeInformation[2],
                            storeInformation[3], storeInformation[4], storeInformation[5]);
                    listOfStore.add(e);
                    //System.out.print(e.toString());
                }
            }

        } catch (FileNotFoundException e) {
            System.out.println("Failed to find the file!");
        } catch (IOException e) {
            System.out.println("Failed to read the file");
        }
    }

}
