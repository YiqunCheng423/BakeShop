package View;

import Control.*;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LoginInterface extends Interface {
    private static JFrame frame;
    private static LoginPanel panel;
    private static JLabel userLabel, passwordLabel, success;
    private static JTextField userText;
    private static JPasswordField passwordText;
    private static JButton button, button2;

    private static JProgressBar pBar;
    private static final int MIN_PROGRESS = 0;
    private static final int MAX_PROGRESS = 100;
    private static int currentProgress = MIN_PROGRESS;

    public LoginInterface() {
        UIManager.put("Label.font", new Font("Arial", Font.PLAIN, 17));
        Gui();
        pBar.setVisible(false);
        panel.add(button);
        panel.add(button2);
        frame.setVisible(true);
        //readData();
    }

    public static void Gui() {
        frame = new JFrame("Bake Shop");
        panel = new LoginPanel();

        frame.setSize(1000, 600);
        frame.setLocation(300, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(panel);

        panel.setLayout(null);
        panel.setBackground(Color.WHITE);

        // User Label
        userLabel = new JLabel("UserID/Email");
        userLabel.setBounds(680, 150, 100, 30);
        panel.add(userLabel);

        // User Text
        userText = new JTextField(20);
        userText.setBounds(800, 150, 170, 40);
        panel.add(userText);

        // Password Label
        passwordLabel = new JLabel("Password");
        passwordLabel.setBounds(680, 250, 100, 30);
        panel.add(passwordLabel);

        // Password Text
        passwordText = new JPasswordField(20);
        passwordText.setBounds(800, 250, 170, 40);
        panel.add(passwordText);

        // Login Button
        button = new JButton("Login");
        button.setBounds(700, 360, 120, 40);
        setButtonBorder(button);
        setMouseMove(button);
        button.addActionListener(new LoginInterface.LoginListener());
        //panel.add(button);

        // Join Us Button
        button2 = new JButton("Join Us");
        button2.setBounds(850, 360, 120, 40);
        setButtonBorder(button2);
        setMouseMove(button2);
        button2.addActionListener(new LoginInterface.JoinListener());
        //panel.add(button2);

        // Login Unsuccessful/Successful text
        success = new JLabel("");
        success.setBounds(800, 500, 300, 25);
        success.setFont(new Font("Kalam", Font.PLAIN, 18));
        success.setForeground(Color.RED);
        panel.add(success);

        //
        //button.setVisible(false);
        //button2.setVisible(false);

        // Progress Bar
        pBar = new JProgressBar();
        pBar.setMinimum(MIN_PROGRESS);
        pBar.setMaximum(MAX_PROGRESS);
        pBar.setValue(currentProgress);
        pBar.setStringPainted(true);
        pBar.setBounds(700, 360, 280, 40);
        pBar.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent changeEvent) {
                if (pBar.getValue() == MAX_PROGRESS) {
                    pBar.setVisible(false);
                    panel.add(button);
                    panel.add(button2);
                    //button.setVisible(true);
                    //button2.setVisible(true);
                }
            }
        });
        panel.add(pBar);

        new Timer(500, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                currentProgress += 6;
                if (currentProgress > MAX_PROGRESS) {
                    currentProgress = MAX_PROGRESS;
                }
                pBar.setValue(currentProgress);
            }
        }).start();
    }

    /*
     * Login button action
     */
    static class LoginListener implements ActionListener {
        /**
         * method name: actionPerformed
         * description:
         * param: [actionEvent]
         * @return void
         */
        @Override
        public void actionPerformed(ActionEvent actionEvent) {
            String userIDOrEmail = userText.getText();
            String password = passwordText.getText();
            try {
                if (loginAccount(userIDOrEmail, password)) {
                    displayNormalInterface(userIDOrEmail, BakeShopSystem.checkStoreID(userIDOrEmail));
                } else {
                    displayLoginError();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    /*
     * Join us button action
     */
    static class JoinListener implements ActionListener {
        /**
         * method name: actionPerformed
         * description:
         * param: [actionEvent]
         * @return void
         */
        @Override
        public void actionPerformed(ActionEvent actionEvent) {
            try {
                registerAccount();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * method name: loginAccount
     * description:
     * param: [userIDOrEmail, password]
     * @return boolean
     */
    public static boolean loginAccount(String userIDOrEmail, String password) {
        boolean userResult;
        userResult = LoginSystem.validateUserIDOrEmail(userIDOrEmail);

        if (!userResult) {
            return false;
        }

        boolean passResult;
        passResult = LoginSystem.validatePassword(userIDOrEmail, password);

        return passResult;
    }

    /**
     * method name: registerAccount
     * description:
     * param: []
     * @return void
     */
    public static void registerAccount() {
        new RegistrationInterface();
        frame.setVisible(false);
    }

    /**
     * method name: displayLoginError
     * description:
     * param: []
     * @return void
     */
    public static void displayLoginError() {
        success.setText(": ( Wrong password!");
    }

    /**
     * method name: displayNormalInterface
     * description:
     * param: [userIDOrEmail, storeID]
     * @return void
     */
    public static void displayNormalInterface(String userIDOrEmail, String storeID) {
        new NormalOrderInterface(userIDOrEmail, storeID);
        frame.setVisible(false);
    }

    /**
     * method name: readData
     * description:
     * param: []
     * @return void
     */
    public static void readData() {
        LoginSystem.readStore();
        RegistrationSystem.readStaff();
        OrderDisplaySystem.readOrder();
        InventorySystem.readInventory();
    }

    /**
     * method name: main
     * description:
     * param: [args]
     * @return void
     */
    public static void main(String[] args) {
        UIManager.put("Label.font", new Font("Arial", Font.PLAIN, 17));
        Gui();
        frame.setVisible(true);
        readData();
    }
}
