package View;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Interface {
    public Interface() {
    }

    public static class BackgroundPanel extends JPanel {
        /**
         * method name: paintComponent
         * description:
         * param: [g]
         * @return void
         */
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            ImageIcon i = new ImageIcon("src/ICON/background.png");
            i.paintIcon(this, g, 0, 0);
        }
    }

    public static class LoginPanel extends JPanel {
        /**
         * method name: paintComponent
         * description:
         * param: [g]
         * @return void
         */
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            ImageIcon i = new ImageIcon("src/ICON/Login.png");
            i.paintIcon(this, g, 0, 0);
        }
    }

    /**
     * method name: setButtonBorder
     * description:
     * param: [i]
     * @return void
     */
    public static void setButtonBorder(JButton i){
        i.setBorder(BorderFactory.createLineBorder(Color.decode("#0abab5")));
        i.setForeground(Color.decode("#0abab5"));
    }

    public static void setMouseMove(JButton i){
        i.addMouseListener(new MouseAdapter() {
            /**
             * method name: mouseEntered
             * description:
             * param: [e]
             * @return void
             */
            @Override
            public void mouseEntered(MouseEvent e) {
                i.setBorder(BorderFactory.createLineBorder(Color.gray));
                i.setForeground(Color.gray);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                i.setBorder(BorderFactory.createLineBorder(Color.decode("#0abab5")));
                i.setForeground(Color.decode("#0abab5"));
            }
        });
    }

    public static class OrderAPanel extends JPanel {
        /**
         * method name: paintComponent
         * description:
         * param: [g]
         * @return void
         */
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            ImageIcon i = new ImageIcon("src/ICON/orderA.png");
            i.paintIcon(this, g, 0, 0);
        }
    }

    public static class OrderBPanel extends JPanel {
        /**
         * method name: paintComponent
         * description:
         * param: [g]
         * @return void
         */
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            ImageIcon i = new ImageIcon("src/ICON/orderB.png");
            i.paintIcon(this, g, 0, 0);
        }
    }

    public static class InfoAPanel extends JPanel {
        /**
         * method name: paintComponent
         * description:
         * param: [g]
         * @return void
         */
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            ImageIcon i = new ImageIcon("src/ICON/InfoA.png");
            i.paintIcon(this, g, 0, 0);
        }
    }

    public static class InfoBPanel extends JPanel {
        /**
         * method name: paintComponent
         * description:
         * param: [g]
         * @return void
         */
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            ImageIcon i = new ImageIcon("src/ICON/InfoB.png");
            i.paintIcon(this, g, 0, 0);
        }
    }
}
