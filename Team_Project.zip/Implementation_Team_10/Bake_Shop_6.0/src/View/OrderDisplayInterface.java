package View;

import Control.BakeShopSystem;
import Control.OrderDisplaySystem;
import Model.AdvancedOrder;
import Model.Order;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class OrderDisplayInterface extends Interface {

    private static JFrame frame;
    private static BackgroundPanel panel;
    private static JPanel insidePanel;
    private static JButton shopButton, displayButton, starButton, settingButton, allCompletedButton;
    private static JLabel titleLabel;
    private static ArrayList<Order> orderList = new ArrayList<>();
    private static ArrayList<JTextArea> orderDisplayList = new ArrayList<>();
    private static ArrayList<AdvancedOrder> advancedOrderList = new ArrayList<>();
    private static JScrollPane scrollPane;

    public OrderDisplayInterface(){
        Gui();
        menuGui();
        orderGui();
        frame.setVisible(true);
    }

    /**
     * method name: Gui
     * description:
     * param: []
     * @return void
     */
    public static void Gui() {
        frame = new JFrame("Bake Shop");
        panel = new BackgroundPanel();

        frame.setSize(1000, 600);
        frame.setLocation(300, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(panel);

        panel.setLayout(null);
        panel.setBackground(Color.WHITE);

        insidePanel = new JPanel();
        insidePanel.setLayout(null);
        insidePanel.setBackground(Color.WHITE);
        int orderSize = orderList.size();
        if (orderSize >= 3) {
            int displaySize = orderSize - 2;
            insidePanel.setPreferredSize(new Dimension(940 + 180 * displaySize,550));
        } else {
            insidePanel.setPreferredSize(new Dimension(940, 550));
        }

        titleLabel = new JLabel("Order Information");
        titleLabel.setFont(new Font("Arial", Font.PLAIN, 25));
        titleLabel.setForeground(Color.decode("#0abab5"));
        titleLabel.setBounds(30, 25, 200, 25);
        insidePanel.add(titleLabel);
    }

    /**
     * method name: menuGui
     * description:
     * param: []
     * @return void
     */
    public static void menuGui(){
        // Main Icon
        shopButton = new JButton(new ImageIcon("src/ICON/shop.png"));
        shopButton.setBounds(0, 0, 60, 60);
        shopButton.addActionListener(new NormalOrderListener());
        panel.add(shopButton);

        displayButton = new JButton(new ImageIcon("src/ICON/displayIN.png"));
        displayButton.setBounds(0, 60, 60, 60);
        panel.add(displayButton);

        starButton = new JButton(new ImageIcon("src/ICON/star.png"));
        starButton.setBounds(0, 120, 60, 60);
        starButton.addActionListener(new InventoryListener());
        panel.add(starButton);

        settingButton = new JButton(new ImageIcon("src/ICON/setting.png"));
        settingButton.setBounds(0, 520, 60, 60);
        settingButton.addActionListener(new SettingListener());
        panel.add(settingButton);
    }

    /**
     * method name: orderGui
     * description:
     * param: []
     * @return void
     */
    public static void orderGui(){
        String storeID = BakeShopSystem.getStoreID();
        orderList = OrderDisplaySystem.searchOrder(storeID);
        advancedOrderList = OrderDisplaySystem.searchAdvancedOrder(storeID);
        scrollPane = new JScrollPane();

        // for normal orders
        for (int i = 0; i < orderList.size(); i++) {
            JScrollPane scroll = new JScrollPane();
            JTextArea text = new JTextArea();
            scroll.setBounds(100 + 230 * i,66,180,160);
            text.setBounds(100 + 230 * i,66,180,160);
            scroll.setViewportView(text);
            text.setFont(new Font("Arial", Font.PLAIN, 13));
            text.setEditable(false);
            text.setBorder(BorderFactory.createLineBorder(Color.GRAY));

            Order order = orderList.get(i);

            String content = "";

            for (int j = 0; j < order.getItems().length; j++) {
                content = content + " " + order.getItems()[j] + "  x" + order.getQuantity()[j] +
                        "  price:" + order.getPrice()[j] + "$" + "\n";
            }

            text.setText("\n" + " Order ID: " + order.getOrderID() + "\n" + " Staff ID: " + order.getStaffID() + "\n" + content
                    + " Total Price: " + order.getTotalAmount() + "\n" + " Date: " + order.getDate() + "\n"
                    + " Time: " + order.getTime() + "\n" + " Customer Name: " + order.getCustName() + "\n");

            text.append(" *** Normal Order ***");

            insidePanel.add(scroll);
        }

        // for advanced orders
        for (int i = 0; i < advancedOrderList.size(); i++) {
            JScrollPane anotherScroll = new JScrollPane();
            JTextArea anotherText = new JTextArea();
            // change location of advanced order
            anotherScroll.setBounds(100 + 230 * i,266,180,160);
            anotherText.setBounds(100 + 230 * i,266,180,160);
            anotherScroll.setViewportView(anotherText);
            anotherText.setFont(new Font("Arial", Font.PLAIN, 13));
            anotherText.setEditable(false);
            anotherText.setBorder(BorderFactory.createLineBorder(Color.GRAY));

            AdvancedOrder advancedOrder = advancedOrderList.get(i);

            String anotherContent = "";

            for (int j = 0; j < advancedOrder.getItems().length; j++) {
                anotherContent = anotherContent + " " + advancedOrder.getItems()[j] + "  x" + advancedOrder.getQuantity()[j] +
                        "  price:" + advancedOrder.getPrice()[j] + "$" + "\n";
            }

            anotherText.setText("\n" + " Order ID: " + advancedOrder.getOrderID() + "\n" + " Staff ID: " + advancedOrder.getStaffID() + "\n" + anotherContent
                    + " Total Price: " + advancedOrder.getTotalAmount() + "\n" + " Date: " + advancedOrder.getDate() + "\n"
                    + " Time: " + advancedOrder.getTime() + "\n" + " Customer Name: " + advancedOrder.getCustName() + "\n");

            anotherText.append(" *** Advanced Order ***");

            insidePanel.add(anotherScroll);
        }

        allCompletedButton = new JButton("All Completed Order");
        allCompletedButton.setBounds(730, 470, 160, 40);
        setButtonBorder(allCompletedButton);
        setMouseMove(allCompletedButton);
        allCompletedButton.addActionListener(new AllCompeletedListener());
        insidePanel.add(allCompletedButton);

        scrollPane.setBounds(60,0,940,580);
        scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
        scrollPane.setViewportView(insidePanel);
        panel.add(scrollPane);
    }

    static class AllCompeletedListener implements ActionListener {
        /**
         * method name: actionPerformed
         * description:
         * param: [actionEvent]
         * @return void
         */
        @Override
        public void actionPerformed(ActionEvent actionEvent) {
            JDialog dialog = new JDialog();
            dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
            dialog.setLocation(500,400);
            dialog.setSize(600,500);

            JScrollPane scroll = new JScrollPane();
            scroll.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
            dialog.add(scroll, BorderLayout.CENTER);

            JTextArea textArea = new JTextArea();
            String displayContent = "";
            displayContent += OrderDisplaySystem.getReadyOrderList() + OrderDisplaySystem.getReadyAdOrderList();
            textArea.setText(displayContent);
            scroll.setViewportView(textArea);

            dialog.setVisible(true);
        }
    }

    static class NormalOrderListener implements ActionListener {
        /**
         * method name: actionPerformed
         * description:
         * param: [actionEvent]
         * @return void
         */
        @Override
        public void actionPerformed(ActionEvent actionEvent) {
            new NormalOrderInterface();
            frame.setVisible(false);
        }
    }

    static class InventoryListener implements ActionListener{
        /**
         * method name: actionPerformed
         * description:
         * param: [actionEvent]
         * @return void
         */
        @Override
        public void actionPerformed(ActionEvent actionEvent) {
            new InventoryInterface();
            frame.setVisible(false);
        }
    }

    static class SettingListener implements ActionListener{
        /**
         * method name: actionPerformed
         * description:
         * param: [actionEvent]
         * @return void
         */
        @Override
        public void actionPerformed(ActionEvent actionEvent) {
            new SettingInterface();
            frame.setVisible(false);
        }
    }

    /**
     * method name: modifyStatus
     * description:
     * param: []
     * @return void
     */
    public void modifyStatus() {

    }

    /**
     * method name: displayCompleteError
     * description:
     * param: []
     * @return void
     */
    public void displayCompleteError() {

    }

    /**
     * method name: deleteOrder
     * description:
     * param: []
     * @return void
     */
    public void deleteOrder() {

    }

    /**
     * method name: main
     * description:
     * param: [args]
     * @return void
     */
    public static void main(String[] args) {
        Gui();
        menuGui();
        orderGui();
        frame.setVisible(true);
    }
}
