package View;

import Control.InventorySystem;
import Control.ReportSystem;
import Model.Item;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.Map;

public class ReportInterface extends Interface {

    private static JFrame frame;
    private static InfoBPanel panel;
    private static JLabel titleLabel, monthLabel, monthRevenueLabel, monthCoffeeNumberLabel,
            monthBeanNumberLabel, monthFoodNumberLabel, totalNumberLabel, mostSaleTypeLabel, coffeeTypeLabel,
            foodTypeLabel, totalSaleLabel, unitLabel, storeLabel;
    private static JButton shopButton, displayButton, starButton, settingButton, mainAButton, mainBButton;
    private static JTextField monthRevenue, monthCoffeeNumber, monthBeanNumber, monthFoodNumber, mostCoffeeType,
            mostFoodType, weekCoffeeDay, weekFoodDay, mostSale;
    private static JComboBox<String> storeBox;

    /**
     * method name: ReportInterface
     * description:
     * param: []
     * @return
     */
    public ReportInterface() {
        Gui();
        menuGui();
        infoGui();
        frame.setVisible(true);
    }

    /**
     * method name: Gui
     * description:
     * param: []
     * @return void
     */
    public static void Gui() {
        frame = new JFrame("Bake Shop");
        panel = new InfoBPanel();

        frame.setSize(1000, 600);
        frame.setLocation(300, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(panel);

        panel.setLayout(null);
        panel.setBackground(Color.WHITE);

        titleLabel = new JLabel("Sales Report");
        titleLabel.setFont(new Font("Arial", Font.PLAIN, 25));
        titleLabel.setForeground(Color.decode("#0abab5"));
        titleLabel.setBounds(250, 25, 200, 25);
        panel.add(titleLabel);

        mainAButton = new JButton("Inventory");
        mainAButton.setBounds(60, 110, 170, 50);
        mainAButton.setOpaque(false);
        mainAButton.setBorder(null);
        mainAButton.addActionListener(new InventoryListener());
        panel.add(mainAButton);

        mainBButton = new JButton("Sales Report");
        mainBButton.setBounds(60, 155, 170, 50);
        mainBButton.setOpaque(false);
        mainBButton.setBorder(null);
        panel.add(mainBButton);
    }

    /**
     * method name: menuGui
     * description:
     * param: []
     * @return void
     */
    public static void menuGui(){
        // Main Icon
        shopButton = new JButton(new ImageIcon("src/ICON/shop.png"));
        shopButton.setBounds(0, 0, 60, 60);
        shopButton.addActionListener(new NormalOrderListener());
        panel.add(shopButton);

        displayButton = new JButton(new ImageIcon("src/ICON/display.png"));
        displayButton.setBounds(0, 60, 60, 60);
        displayButton.addActionListener(new OrderDisplayListener());
        panel.add(displayButton);

        starButton = new JButton(new ImageIcon("src/ICON/starIN.png"));
        starButton.setBounds(0, 120, 60, 60);
        panel.add(starButton);

        settingButton = new JButton(new ImageIcon("src/ICON/setting.png"));
        settingButton.setBounds(0, 520, 60, 60);
        settingButton.addActionListener(new SettingListener());
        panel.add(settingButton);
    }

    /**
     * method name: infoGui
     * description:
     * param: []
     * @return void
     */
    public static void infoGui(){
        // Month
        monthLabel = new JLabel("Last Month");
        monthLabel.setBounds(250, 130,200,50);
        monthLabel.setForeground(Color.decode("#0abab5"));
        monthLabel.setFont(new Font("Arial", Font.BOLD, 20));
        panel.add(monthLabel);

        monthRevenueLabel = new JLabel("Revenue($):");
        monthRevenueLabel.setBounds(250, 190,200,50);
        monthRevenueLabel.setForeground(Color.GRAY);
        monthRevenueLabel.setFont(new Font("Arial", Font.BOLD, 18));
        panel.add(monthRevenueLabel);

        // R
        monthRevenue = new JTextField("" + ReportSystem.calculateRevenue());
        monthRevenue.setBounds(370,190,200,50);
        monthRevenue.setFont(new Font("Arial", Font.ITALIC, 18));
        monthRevenue.setForeground(Color.GRAY);
        monthRevenue.setBorder(null);
        monthRevenue.setEditable(false);
        panel.add(monthRevenue);

        totalNumberLabel = new JLabel("Total Number Sale:");
        totalNumberLabel.setBounds(250, 260,180,50);
        totalNumberLabel.setForeground(Color.GRAY);
        totalNumberLabel.setFont(new Font("Arial", Font.BOLD, 18));
        panel.add(totalNumberLabel);

        unitLabel = new JLabel("(A serving)");
        unitLabel.setBounds(280, 300,180,50);
        unitLabel.setForeground(Color.GRAY);
        unitLabel.setFont(new Font("Arial", Font.BOLD, 15));
        panel.add(unitLabel);

        monthCoffeeNumberLabel = new JLabel("Coffee:");
        monthCoffeeNumberLabel.setBounds(450, 260,200,50);
        monthCoffeeNumberLabel.setForeground(Color.GRAY);
        monthCoffeeNumberLabel.setFont(new Font("Arial", Font.BOLD, 18));
        panel.add(monthCoffeeNumberLabel);

        // R
        monthCoffeeNumber = new JTextField("" + ReportSystem.calculateCoffee());
        monthCoffeeNumber.setBounds(540, 260,150,50);
        monthCoffeeNumber.setFont(new Font("Arial", Font.ITALIC, 18));
        monthCoffeeNumber.setForeground(Color.GRAY);
        monthCoffeeNumber.setBorder(null);
        panel.add(monthCoffeeNumber);

        monthFoodNumberLabel = new JLabel("Food:");
        monthFoodNumberLabel.setBounds(450, 330,200,50);
        monthFoodNumberLabel.setForeground(Color.GRAY);
        monthFoodNumberLabel.setFont(new Font("Arial", Font.BOLD, 18));
        panel.add(monthFoodNumberLabel);

        // R
        monthFoodNumber = new JTextField("" + ReportSystem.calculateFood());
        monthFoodNumber.setBounds(540, 330,220,50);
        monthFoodNumber.setFont(new Font("Arial", Font.ITALIC, 18));
        monthFoodNumber.setForeground(Color.GRAY);
        monthFoodNumber.setBorder(null);
        panel.add(monthFoodNumber);

        monthBeanNumberLabel = new JLabel("Coffee Beans:");
        monthBeanNumberLabel.setBounds(690, 260,200,50);
        monthBeanNumberLabel.setForeground(Color.GRAY);
        monthBeanNumberLabel.setFont(new Font("Arial", Font.BOLD, 18));
        panel.add(monthBeanNumberLabel);

        // R
        monthBeanNumber = new JTextField("" + ReportSystem.calculateCoffeeBeans());
        monthBeanNumber.setBounds(830, 260,150,50);
        monthBeanNumber.setFont(new Font("Arial", Font.ITALIC, 18));
        monthBeanNumber.setForeground(Color.GRAY);
        monthBeanNumber.setBorder(null);
        panel.add(monthBeanNumber);

        //
        mostSaleTypeLabel = new JLabel("Most Sale Type:");
        mostSaleTypeLabel.setBounds(250, 380,200,50);
        mostSaleTypeLabel.setForeground(Color.GRAY);
        mostSaleTypeLabel.setFont(new Font("Arial", Font.BOLD, 18));
        panel.add(mostSaleTypeLabel);

        coffeeTypeLabel = new JLabel("Coffee:");
        coffeeTypeLabel.setBounds(450, 380,200,50);
        coffeeTypeLabel.setForeground(Color.GRAY);
        coffeeTypeLabel.setFont(new Font("Arial", Font.BOLD, 18));
        panel.add(coffeeTypeLabel);

        // R
        mostCoffeeType = new JTextField("" + ReportSystem.findMostSaleCoffe());
        mostCoffeeType.setBounds(540, 380,150,50);
        mostCoffeeType.setFont(new Font("Arial", Font.ITALIC, 18));
        mostCoffeeType.setForeground(Color.GRAY);
        mostCoffeeType.setBorder(null);
        panel.add(mostCoffeeType);

        // R
        weekCoffeeDay = new JTextField(ReportSystem.findDaySaleCoffee());
        weekCoffeeDay.setBounds(700, 380,150,50);
        weekCoffeeDay.setFont(new Font("Arial", Font.ITALIC, 18));
        weekCoffeeDay.setForeground(Color.GRAY);
        weekCoffeeDay.setBorder(null);
        panel.add(weekCoffeeDay);

        foodTypeLabel = new JLabel("Food:");
        foodTypeLabel.setBounds(450, 450,200,50);
        foodTypeLabel.setForeground(Color.GRAY);
        foodTypeLabel.setFont(new Font("Arial", Font.BOLD, 18));
        panel.add(foodTypeLabel);

        // R
        mostFoodType = new JTextField(ReportSystem.findMostSaleFood());
        mostFoodType.setBounds(540, 450,150,50);
        mostFoodType.setFont(new Font("Arial", Font.ITALIC, 18));
        mostFoodType.setForeground(Color.GRAY);
        mostFoodType.setBorder(null);
        panel.add(mostFoodType);

        // R
        weekFoodDay = new JTextField(ReportSystem.findDaySaleFood());
        weekFoodDay.setBounds(700, 450,150,50);
        weekFoodDay.setFont(new Font("Arial", Font.ITALIC, 18));
        weekFoodDay.setForeground(Color.GRAY);
        weekFoodDay.setBorder(null);
        panel.add(weekFoodDay);

        totalSaleLabel = new JLabel("Total Sale($):");
        totalSaleLabel.setBounds(250, 520,200,50);
        totalSaleLabel.setForeground(Color.GRAY);
        totalSaleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        panel.add(totalSaleLabel);

        // R
        mostSale = new JTextField("" + ReportSystem.calculateTotalSale());
        mostSale.setBounds(380,520,200,50);
        mostSale.setFont(new Font("Arial", Font.ITALIC, 18));
        mostSale.setForeground(Color.GRAY);
        mostSale.setBorder(null);
        mostSale.setEditable(false);
        panel.add(mostSale);

        // Change the store
        String[] storeList = new String[]{"1", "2", "3", "4", "5", "6", "7", "8", "9", "10"};
        storeBox = new JComboBox<String>(storeList);
        storeBox.setSelectedIndex(0);
        storeBox.setBounds(425, 45, 150, 100);
        storeBox.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent itemEvent) {
                if (itemEvent.getStateChange() == ItemEvent.SELECTED) {
                    String number = (String) itemEvent.getItem();
                    ReportSystem.setSelectedStore(number);
                    updateInfo();
                }

            }
        });
        panel.add(storeBox);

        storeLabel = new JLabel("Choose a store:");
        storeLabel.setBounds(250, 70,200,50);
        storeLabel.setForeground(Color.decode("#0abab5"));
        storeLabel.setFont(new Font("Arial", Font.BOLD, 20));
        panel.add(storeLabel);
    }

    /**
     * method name: updateInfo
     * description:
     * param: []
     * @return void
     */
    public static void updateInfo() {
        monthRevenue.setText("" + ReportSystem.calculateRevenue());
        monthCoffeeNumber.setText("" + ReportSystem.calculateCoffee());
        monthFoodNumber.setText("" + ReportSystem.calculateFood());
        monthBeanNumber.setText("" + ReportSystem.calculateCoffeeBeans());
        mostCoffeeType.setText("" + ReportSystem.findMostSaleCoffe());
        weekCoffeeDay.setText("" + ReportSystem.findDaySaleCoffee());
        mostFoodType.setText("" + ReportSystem.findMostSaleFood());
        weekFoodDay.setText("" + ReportSystem.findDaySaleFood());
        mostSale.setText("" + ReportSystem.calculateTotalSale());
    }

    static class InventoryListener implements ActionListener{
        /**
         * method name: actionPerformed
         * description:
         * param: [actionEvent]
         * @return void
         */
        @Override
        public void actionPerformed(ActionEvent actionEvent) {
            new InventoryInterface();
            frame.setVisible(false);
        }
    }

    static class NormalOrderListener implements ActionListener {
        /**
         * method name: actionPerformed
         * description:
         * param: [actionEvent]
         * @return void
         */
        @Override
        public void actionPerformed(ActionEvent actionEvent) {
            new NormalOrderInterface();
            frame.setVisible(false);
        }
    }

    static class OrderDisplayListener implements ActionListener{
        /**
         * method name: actionPerformed
         * description:
         * param: [actionEvent]
         * @return void
         */
        @Override
        public void actionPerformed(ActionEvent actionEvent) {
            new OrderDisplayInterface();
            frame.setVisible(false);
        }
    }

    static class SettingListener implements ActionListener{
        /**
         * method name: actionPerformed
         * description:
         * param: [actionEvent]
         * @return void
         */
        @Override
        public void actionPerformed(ActionEvent actionEvent) {
            new SettingInterface();
            frame.setVisible(false);
        }
    }

    /**
     * method name: displayMonthReport
     * description:
     * param: []
     * @return void
     */
    public void displayMonthReport() {
    }

    /**
     * method name: displayWeekReport
     * description:
     * param: []
     * @return void
     */
    public void displayWeekReport() {

    }

    /**
     * method name: main
     * description:
     * param: [args]
     * @return void
     */
    public static void main(String[] args) {
        Gui();
        menuGui();
        infoGui();
        frame.setVisible(true);
    }
}
