package View;

import Control.BakeShopSystem;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SettingInterface extends Interface {

    private static JFrame frame;
    private static BackgroundPanel panel;
    private static JButton shopButton, displayButton, starButton, settingButton, funButton, logoutButton, changeButton;
    private static JLabel titleLabel, teamLabel, storeLabel, infoLabel;
    private static JComboBox<String> teamBox;

    /**
     * method name: SettingInterface
     * description:
     * param: []
     * @return
     */
    public SettingInterface() {
        Gui();
        menuGui();
        frame.setVisible(true);
    }

    /**
     * method name: Gui
     * description:
     * param: []
     * @return void
     */
    public static void Gui() {
        frame = new JFrame("Bake Shop");
        panel = new BackgroundPanel();

        frame.setSize(1000, 600);
        frame.setLocation(300, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(panel);

        panel.setLayout(null);
        panel.setBackground(Color.WHITE);

        titleLabel = new JLabel("Setting");
        titleLabel.setFont(new Font("Arial", Font.PLAIN, 25));
        titleLabel.setForeground(Color.decode("#0abab5"));
        titleLabel.setBounds(100, 25, 200, 25);
        panel.add(titleLabel);

        funButton = new JButton("");
        funButton.setBounds(90, 25, 100, 25);
        funButton.addActionListener(new FunListener());
        funButton.setOpaque(false);
        funButton.setBorder(null);
        panel.add(funButton);

        teamLabel = new JLabel("FIT5136 Team10");
        teamLabel.setFont(new Font("Arial", Font.PLAIN, 15));
        teamLabel.setBounds(700, 500, 150, 100);
        panel.add(teamLabel);

        String[] teamList = new String[]{"Team Member", "Qiyao Ye", "Zhaoqi Wang", "Zijian Zhang", "Yiqun Cheng"};
        teamBox = new JComboBox<String>(teamList);
        teamBox.setSelectedIndex(0);
        teamBox.setBounds(820, 500, 150, 100);
        panel.add(teamBox);

        logoutButton = new JButton("Logout");
        logoutButton.setBounds(830, 470, 120, 40);
        setButtonBorder(logoutButton);
        setMouseMove(logoutButton);
        logoutButton.addActionListener(new LogoutListener());
        panel.add(logoutButton);

        storeLabel = new JLabel("Current store: " + BakeShopSystem.getStoreID());
        storeLabel.setForeground(Color.decode("#0abab5"));
        storeLabel.setBounds(100, 100, 200, 50);
        storeLabel.setFont(new Font("Arial", Font.PLAIN, 18));
        panel.add(storeLabel);

        changeButton = new JButton("Change");
        changeButton.setBounds(280, 100, 120, 40);
        setButtonBorder(changeButton);
        setMouseMove(changeButton);
        changeButton.addActionListener(new ChangeListener());
        panel.add(changeButton);

        infoLabel = new JLabel("Personal Information:");
        infoLabel.setForeground(Color.decode("#0abab5"));
        infoLabel.setBounds(100, 175, 200, 50);
        infoLabel.setFont(new Font("Arial", Font.PLAIN, 18));
        panel.add(infoLabel);

    }

    /**
     * method name: menuGui
     * description:
     * param: []
     * @return void
     */
    public static void menuGui() {
        // Main Icon
        shopButton = new JButton(new ImageIcon("src/ICON/shop.png"));
        shopButton.setBounds(0, 0, 60, 60);
        shopButton.addActionListener(new NormalOrderListener());
        panel.add(shopButton);

        displayButton = new JButton(new ImageIcon("src/ICON/display.png"));
        displayButton.setBounds(0, 60, 60, 60);
        displayButton.addActionListener(new OrderDisplayListener());
        panel.add(displayButton);

        starButton = new JButton(new ImageIcon("src/ICON/star.png"));
        starButton.setBounds(0, 120, 60, 60);
        starButton.addActionListener(new InventoryListener());
        panel.add(starButton);

        settingButton = new JButton(new ImageIcon("src/ICON/settingIN.png"));
        settingButton.setBounds(0, 520, 60, 60);
        panel.add(settingButton);
    }

    static class ChangeListener implements ActionListener {
        /**
         * method name: actionPerformed
         * description:
         * param: [actionEvent]
         * @return void
         */
        @Override
        public void actionPerformed(ActionEvent actionEvent) {
            String ID = JOptionPane.showInputDialog(null, "Please enter the store ID which you want to go!");
            if (!ID.equals("")) {
                frame.setVisible(false);
                NormalOrderInterface.setStoreID(ID);
                new SettingInterface();
            } else {
                JOptionPane.showMessageDialog(null, "You should enter valid store ID!");
            }

        }
    }

    static class NormalOrderListener implements ActionListener {
        /**
         * method name: actionPerformed
         * description:
         * param: [actionEvent]
         * @return void
         */
        @Override
        public void actionPerformed(ActionEvent actionEvent) {
            new NormalOrderInterface();
            frame.setVisible(false);
        }
    }

    static class OrderDisplayListener implements ActionListener {
        /**
         * method name: actionPerformed
         * description:
         * param: [actionEvent]
         * @return void
         */
        @Override
        public void actionPerformed(ActionEvent actionEvent) {
            new OrderDisplayInterface();
            frame.setVisible(false);
        }
    }

    static class InventoryListener implements ActionListener {
        /**
         * method name: actionPerformed
         * description:
         * param: [actionEvent]
         * @return void
         */
        @Override
        public void actionPerformed(ActionEvent actionEvent) {
            new InventoryInterface();
            frame.setVisible(false);
        }
    }

    static class FunListener implements ActionListener {
        /**
         * method name: actionPerformed
         * description:
         * param: [actionEvent]
         * @return void
         */
        @Override
        public void actionPerformed(ActionEvent actionEvent) {
            JOptionPane.showMessageDialog(null, new ImageIcon("src/ICON/fun.jpg"));
        }
    }

    static class LogoutListener implements ActionListener {
        /**
         * method name: actionPerformed
         * description:
         * param: [actionEvent]
         * @return void
         */
        @Override
        public void actionPerformed(ActionEvent actionEvent) {
            new LoginInterface();
            frame.setVisible(false);
        }
    }

    /**
     * method name: changeStoreRequest
     * description:
     * param: []
     * @return void
     */
    public void changeStoreRequest() {

    }

    /**
     * method name: displayChangeError
     * description:
     * param: []
     * @return void
     */
    public void displayChangeError() {

    }

    /**
     * method name: enterStoreID
     * description:
     * param: []
     * @return String
     */
    public String enterStoreID() {
        return null;
    }

    /**
     * method name: displayEnterError
     * description:
     * param: []
     * @return void
     */
    public void displayEnterError() {

    }

    /**
     * method name: manageStaff
     * description:
     * param: []
     * @return void
     */
    public void manageStaff() {

    }

    /**
     * method name: enterStaffID
     * description:
     * param: []
     * @return String
     */
    public String enterStaffID() {
        return null;
    }

    /**
     * method name: displayManagementError
     * description:
     * param: []
     * @return void
     */
    public void displayManagementError() {

    }

    /**
     * method name: displayStaffDetails
     * description:
     * param: []
     * @return void
     */
    public void displayStaffDetails() {

    }

    /**
     * method name: enterEmail
     * description:
     * param: []
     * @return String
     */
    public String enterUsername() {
        return null;
    }

    /**
     * method name: enterEmail
     * description:
     * param: []
     * @return String
     */
    public String enterPassword() {
        return null;
    }

    /**
     * method name: enterEmail
     * description:
     * param: []
     * @return String
     */
    public String enterPhone() {
        return null;
    }

    /**
     * method name: enterEmail
     * description:
     * param: []
     * @return String
     */
    public String enterCity() {
        return null;
    }

    /**
     * method name: enterEmail
     * description:
     * param: []
     * @return String
     */
    public String enterPostal() {

        return null;
    }

    /**
     * method name: enterEmail
     * description:
     * param: []
     * @return String
     */
    public String enterEmail() {
        return null;
    }

    /**
     * method name: enterTFN
     * description:
     * param: []
     * @return String
     */
    public String enterTFN() {
        return null;
    }

    /**
     * method name: enterStreet
     * description:
     * param: []
     * @return String
     */
    public String enterStreet() {
        return null;
    }

    /**
     * method name: enterState
     * description:
     * param: []
     * @return String
     */
    public String enterState() {
        return null;
    }

    /**
     * method name: enterStoreId
     * description:
     * param: []
     * @return String
     */
    public String enterStoreId() {
        return null;
    }

    /**
     * method name: main
     * description:
     * param: [args]
     * @return void
     */
    public static void main(String[] args) {
        Gui();
        menuGui();
        frame.setVisible(true);
    }
}
