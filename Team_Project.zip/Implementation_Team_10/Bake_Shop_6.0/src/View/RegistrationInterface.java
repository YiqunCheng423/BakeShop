package View;

import Control.BakeShopSystem;
import Control.RegistrationSystem;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class RegistrationInterface extends Interface {

    private static JFrame frame;
    private static BackgroundPanel panel;
    private static JLabel nameLabel, emailLabel, passLabel, TFNLabel, phoneLabel, addressLabel,
            storeLabel, authorityLabel, cityLabel, stateLabel, postalLabel, success;
    private static JTextField nameText, emailText, passText, TFNText, phoneText, addressText,
            storeText, cityText, authorityText, stateText, postalText;
    private static JButton backButton, joinButton;

    /**
     * method name: RegistrationInterface
     * description:
     * param: []
     * @return
     */
    public RegistrationInterface() {
        Gui();
        frame.setVisible(true);
    }

    /**
     * method name: Gui
     * description:
     * param: []
     * @return void
     */
    public static void Gui() {
        frame = new JFrame("Bake Shop");
        panel = new BackgroundPanel();

        frame.setSize(1000, 600);
        frame.setLocation(300, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(panel);

        panel.setLayout(null);
        panel.setBackground(Color.WHITE);

        // Label and Text
        nameLabel = new JLabel("Name");
        nameLabel.setBounds(150, 55, 150, 60);
        panel.add(nameLabel);

        nameText = new JTextField();
        nameText.setBounds(250,55,250,50);
        panel.add(nameText);

        emailLabel = new JLabel("Email");
        emailLabel.setBounds(600, 55, 150, 60);
        panel.add(emailLabel);

        emailText = new JTextField();
        emailText.setBounds(700, 55, 250,50);
        panel.add(emailText);

        passLabel = new JLabel("Password");
        passLabel.setBounds(150, 130, 150, 60);
        panel.add(passLabel);

        passText = new JTextField();
        passText.setBounds(250, 130, 250, 50);
        panel.add(passText);

        TFNLabel = new JLabel("TFN");
        TFNLabel.setBounds(600, 130, 150, 60);
        panel.add(TFNLabel);

        TFNText = new JTextField();
        TFNText.setBounds(700, 130, 250, 50);
        panel.add(TFNText);

        phoneLabel = new JLabel("Phone");
        phoneLabel.setBounds(150, 205, 150, 60);
        panel.add(phoneLabel);

        phoneText = new JTextField();
        phoneText.setBounds(250, 205, 250, 50);
        panel.add(phoneText);

        authorityLabel = new JLabel("Authority");
        authorityLabel.setBounds(600, 205, 150, 60);
        panel.add(authorityLabel);

        authorityText = new JTextField();
        authorityText.setBounds(700, 205, 250, 50);
        panel.add(authorityText);

        // Store ID
        storeLabel = new JLabel("Store ID");
        storeLabel.setBounds(150, 280, 150, 60);
        panel.add(storeLabel);

        storeText = new JTextField();
        storeText.setBounds(250, 280, 250, 50);
        panel.add(storeText);

        // Street
        addressLabel = new JLabel("Street");
        addressLabel.setBounds(600, 280, 150, 60);
        panel.add(addressLabel);

        addressText = new JTextField();
        addressText.setBounds(700, 280, 250, 50);
        panel.add(addressText);

        // City
        cityLabel = new JLabel("City");
        cityLabel.setBounds(150, 355, 150, 60);
        panel.add(cityLabel);

        cityText = new JTextField();
        cityText.setBounds(250, 355, 250, 50);
        panel.add(cityText);

        // State
        stateLabel = new JLabel("State");
        stateLabel.setBounds(600, 355, 150, 60);
        panel.add(stateLabel);

        stateText = new JTextField();
        stateText.setBounds(700, 355, 250, 50);
        panel.add(stateText);

        // Postal
        postalLabel = new JLabel("Postal");
        postalLabel.setBounds(150,430,150,60);
        panel.add(postalLabel);

        postalText = new JTextField();
        postalText.setBounds(250,430,250,50);
        panel.add(postalText);

        // Button
        backButton = new JButton("Back");
        backButton.setBounds(550, 480, 120, 40);
        setButtonBorder(backButton);
        setMouseMove(backButton);
        backButton.addActionListener(new BackListener());
        panel.add(backButton);

        joinButton = new JButton("Next");
        joinButton.setBounds(760, 480, 120, 40);
        setButtonBorder(joinButton);
        setMouseMove(joinButton);
        joinButton.addActionListener(new JoinListener());
        panel.add(joinButton);

        // Login Unsuccessful/Successful text
        success = new JLabel("");
        success.setBounds(500, 530, 300, 25);
        success.setFont(new Font("Kalam", Font.PLAIN, 18));
        success.setForeground(Color.RED);
        panel.add(success);
    }

    static class BackListener implements ActionListener {
        /**
         * method name: actionPerformed
         * description:
         * param: [actionEvent]
         * @return void
         */
        @Override
        public void actionPerformed(ActionEvent actionEvent) {
            new LoginInterface();
            frame.setVisible(false);
        }
    }

    static class JoinListener implements ActionListener{
        /**
         * method name: actionPerformed
         * description:
         * param: [actionEvent]
         * @return void
         */
        @Override
        public void actionPerformed(ActionEvent actionEvent) {
            try {
                String username = nameText.getText();
                String password = passText.getText();
                String email = emailText.getText();
                String TFN = TFNText.getText();
                String address = addressText.getText();
                String city = cityText.getText();
                String state = stateText.getText();
                String phone = phoneText.getText();
                String storeID = storeText.getText();
                String authority = authorityText.getText();
                String postal = postalText.getText();

                if (register(username,password,email,TFN,address,city,state,phone,storeID,authority,postal)) {
                    String staffID = RegistrationSystem.createNewEmployee(username,email,password,TFN,address,city,state,postal,phone,storeID,authority);
                    if (authority.equals("Owner")){
                        storeID = "1|2|3|4|5|6|7|8|9|10";
                    }
                    RegistrationSystem.writeStaff(staffID,username,email,password,authority,TFN,address,city,state,postal,phone,storeID);
                    displayRegistrationSuccessful(username);
                }
                else{
                    displayRegistrationError();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * method name: register
     * description:
     * param: [username, password, email, TFN, address, city, state, phone, storeID, authority, postal]
     * @return boolean
     */
    public static boolean register(String username,String password,String email,String TFN,String address,String city,String state,String phone,String storeID,String authority,String postal) {
        if (username.length() == 0 || password.length() == 0 || email.length() == 0
                || TFN.length() == 0 || address.length() == 0 || phone.length() == 0 || city.length() == 0 || state.length() == 0 || storeID.length() == 0 || postal.length() == 0){
            return false;
        }
        else {
            if (authority.equals("Owner")) {
                return true;
            } else if (authority.equals("Staff")) {
                return true;
            } else if(authority.equals("Manager")) {
                return true;
            }
            return false;
        }
    }

    // Validation

    /**
     * method name: displayRegistrationError
     * description:
     * param: []
     * @return void
     */
    public static void displayRegistrationError() {
        success.setText("Wrong input!");
    }

    /**
     * method name: displayRegistrationSuccessful
     * description:
     * param: [userIDOrEmail]
     * @return void
     */
    public static void displayRegistrationSuccessful(String userIDOrEmail) {
        new NormalOrderInterface(userIDOrEmail, BakeShopSystem.checkStoreID(userIDOrEmail));
        frame.setVisible(false);
        JOptionPane.showMessageDialog(null, "Registration successful!");
    }

    /**
     * method name: main
     * description:
     * param: [args]
     * @return void
     */
    public static void main(String[] args) {
        Gui();
        frame.setVisible(true);
    }
}
