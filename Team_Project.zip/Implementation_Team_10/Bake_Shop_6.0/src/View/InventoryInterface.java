package View;

import Control.InventorySystem;
import Model.Item;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Map;

public class InventoryInterface extends Interface {

    private static JFrame frame;
    private static InfoAPanel panel;
    private static JButton shopButton, displayButton, starButton, settingButton, mainAButton, mainBButton;
    private static JLabel titleLabel, lowLabel;
    private static JScrollPane inventoryScroll;
    private static JList<String> itemList;
    private static ArrayList<String> items;
    private static JComboBox<String> box;

    public InventoryInterface() {
        Gui();
        infoGui();
        menuGui();
        frame.setVisible(true);
    }

    /**
     * method name: Gui
     * description:
     * param: []
     * @return void
     */
    public static void Gui() {
        frame = new JFrame("Bake Shop");
        panel = new InfoAPanel();

        frame.setSize(1000, 600);
        frame.setLocation(300, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(panel);

        panel.setLayout(null);
        panel.setBackground(Color.WHITE);

        titleLabel = new JLabel("Inventory");
        titleLabel.setFont(new Font("Arial", Font.PLAIN, 25));
        titleLabel.setForeground(Color.decode("#0abab5"));
        titleLabel.setBounds(250, 25, 200, 25);
        panel.add(titleLabel);

        mainAButton = new JButton("Inventory");
        mainAButton.setBounds(60, 110, 170, 50);
        mainAButton.setOpaque(false);
        mainAButton.setBorder(null);
        panel.add(mainAButton);

        mainBButton = new JButton("Sales Report");
        mainBButton.setBounds(60, 155, 170, 50);
        mainBButton.setOpaque(false);
        mainBButton.setBorder(null);
        mainBButton.addActionListener(new ReportListener());
        panel.add(mainBButton);
    }

    /**
     * method name: Gui
     * description:
     * param: []
     * @return void
     */
    public static void infoGui() {
        lowLabel = new JLabel("Low Inventory Items:");
        lowLabel.setForeground(Color.decode("#0abab5"));
        lowLabel.setBounds(250, 100, 200, 50);
        lowLabel.setFont(new Font("Arial", Font.PLAIN, 18));
        panel.add(lowLabel);

        //
        items = new ArrayList<>();
        itemList = new JList<>(items.toArray(new String[0]));
        itemList.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (itemList.getSelectedIndex() != -1) {
                    if (e.getClickCount() == 2) {
                        String name = items.get(itemList.getSelectedIndex()).split(" {3}")[0].trim();
                        String content = "How much " + name + " you want to add?";
                        String number = JOptionPane.showInputDialog(null, content);
                        if (number.matches("[0-9]+") && !number.equals("")) {
                            InventorySystem.addInventory(name, Integer.parseInt(number));
                            frame.setVisible(false);
                            new InventoryInterface();
                        } else {
                            JOptionPane.showMessageDialog(null, "You should only input positive number!");
                        }
                    }
                }
            }
        });
        inventoryScroll = new JScrollPane(itemList);
        inventoryScroll.setBounds(250, 170, 650, 300);
        inventoryScroll.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        panel.add(inventoryScroll);

        // Analyse
        Map<Item, Integer> mapOfItems = InventorySystem.searchItem();
        for (Map.Entry<Item, Integer> entry : mapOfItems.entrySet()) {
            String itemName = entry.getKey().getItemName();
            if (entry.getValue() <= 20) {
                items.add(itemName + "   x" + entry.getValue());
            }
        }
        itemList.setListData(items.toArray(new String[0]));

        String[] chooseList = new String[]{"Low Inventory Items", "All Items"};
        box = new JComboBox<String>(chooseList);
        box.setSelectedIndex(0);
        box.setBounds(450, 75, 180, 100);
        box.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent itemEvent) {
                items.clear();
                if (itemEvent.getStateChange() == ItemEvent.SELECTED) {
                    String one = (String) itemEvent.getItem();

                    Map<Item, Integer> mapOfItems = InventorySystem.searchItem();
                    for (Map.Entry<Item, Integer> entry : mapOfItems.entrySet()) {
                        String itemName = entry.getKey().getItemName();
                        if (one.equals("Low Inventory Items")) {
                            if (entry.getValue() <= 20) {
                                items.add(itemName + "   x" + entry.getValue());
                            }
                        } else {
                            items.add(itemName + "   x" + entry.getValue());
                        }
                    }
                    itemList.setListData(items.toArray(new String[items.size()]));
                }
            }
        });
        panel.add(box);

    }

    /**
     * method name: menuGui
     * description:
     * param: []
     * @return void
     */
    public static void menuGui() {
        // Main Icon
        shopButton = new JButton(new ImageIcon("src/ICON/shop.png"));
        shopButton.setBounds(0, 0, 60, 60);
        shopButton.addActionListener(new NormalOrderListener());
        panel.add(shopButton);

        displayButton = new JButton(new ImageIcon("src/ICON/display.png"));
        displayButton.setBounds(0, 60, 60, 60);
        displayButton.addActionListener(new OrderDisplayListener());
        panel.add(displayButton);

        starButton = new JButton(new ImageIcon("src/ICON/starIN.png"));
        starButton.setBounds(0, 120, 60, 60);
        panel.add(starButton);

        settingButton = new JButton(new ImageIcon("src/ICON/setting.png"));
        settingButton.setBounds(0, 520, 60, 60);
        settingButton.addActionListener(new SettingListener());
        panel.add(settingButton);
    }

    static class AllListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent actionEvent) {

        }
    }

    static class ReportListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent actionEvent) {
            new ReportInterface();
            frame.setVisible(false);
        }
    }

    static class NormalOrderListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent actionEvent) {
            new NormalOrderInterface();
            frame.setVisible(false);
        }
    }

    static class OrderDisplayListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent actionEvent) {
            new OrderDisplayInterface();
            frame.setVisible(false);
        }
    }

    static class SettingListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent actionEvent) {
            new SettingInterface();
            frame.setVisible(false);
        }
    }

    public void displayInformation() {

    }

    public void displayLowInformation() {

    }

    public int enterAddedInventoryNumber() {
        return 0;
    }

    public void displayAddedError() {

    }

    /**
     * method name: main
     * description:
     * param: [args]
     * @return void
     */
    public static void main(String[] args) {
        Gui();
        infoGui();
        menuGui();
        frame.setVisible(true);
    }
}
