package View;

import Control.BakeShopSystem;
import Control.OrderDisplaySystem;
import Model.Item;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class NormalOrderInterface extends Interface {
    private Map<Item, Integer> mapOfItems;
    private String userIDOrEmail;
    private static String storeID;

    private static JFrame frame;
    private static OrderAPanel panel;
    private static JLabel titleLabel, itemNameLabel, itemNumber, itemNumberLabel, priceLabel, totalPriceLabel,
            storeLabel;
    private static JTextField itemNameText, time;
    private static JButton shopButton, displayButton, starButton, settingButton, mainAButton, mainBButton, addButton,
            createButton;
    private static JList<String> itemList;
    private static JScrollPane itemScroll;
    private static ArrayList<String> items;

    /**
     * method name: NormalOrderInterface
     * description: Constructor
     * param: [userIDOrEmail, storeID]
     * @return
     */
    public NormalOrderInterface(String userIDOrEmail, String storeID) {
        this.userIDOrEmail = userIDOrEmail;
        NormalOrderInterface.storeID = storeID;
        BakeShopSystem.setUserIDOrEmail(userIDOrEmail);
        BakeShopSystem.setStoreID(storeID);
        Gui();
        menuGui();
        orderGui();
        frame.setVisible(true);
    }

    /**
     * method name: NormalOrderInterface
     * description: Default Constructor
     * param: [userIDOrEmail, storeID]
     * @return
     */
    public NormalOrderInterface() {
        Gui();
        menuGui();
        orderGui();
        frame.setVisible(true);
    }

    /**
     * method name: setStoreID
     * description:
     * param: [storeID]
     * @return void
     */
    public static void setStoreID(String storeID) {
        NormalOrderInterface.storeID = storeID;
        BakeShopSystem.setStoreID(storeID);
    }

    /**
     * method name: Gui
     * description:
     * param: []
     * @return void
     */
    public static void Gui() {
        frame = new JFrame("Bake Shop");
        panel = new OrderAPanel();

        frame.setSize(1000, 600);
        frame.setLocation(300, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(panel);

        panel.setLayout(null);
        panel.setBackground(Color.WHITE);

        titleLabel = new JLabel("Create An Order");
        titleLabel.setFont(new Font("Arial", Font.PLAIN, 25));
        titleLabel.setForeground(Color.decode("#0abab5"));
        titleLabel.setBounds(250, 25, 200, 25);
        panel.add(titleLabel);

        mainAButton = new JButton("Normal Order");
        mainAButton.setBounds(60, 1, 170, 50);
        mainAButton.setOpaque(false);
        mainAButton.setBorder(null);
        panel.add(mainAButton);

        mainBButton = new JButton("Advanced Order");
        mainBButton.setBounds(60, 46, 170, 50);
        mainBButton.setOpaque(false);
        mainBButton.setBorder(null);
        mainBButton.addActionListener(new AdvancedOrderListener());
        panel.add(mainBButton);
    }

    /**
     * method name: orderGui
     * description:
     * param: []
     * @return void
     */
    public static void orderGui() {
        // Enter item label
        itemNameLabel = new JLabel("Please enter item name: ");
        itemNameLabel.setBounds(250, 160, 200, 50);
        itemNameLabel.setForeground(Color.decode("#0abab5"));
        panel.add(itemNameLabel);

        // Enter item text
        itemNameText = new JTextField();
        itemNameText.setBounds(450, 160, 200, 50);
        itemNameText.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent documentEvent) {
                String itemName = itemNameText.getText().trim();
                String itemNumber = BakeShopSystem.checkItemNumber(itemName);
                if (itemNumber == null) {
                    NormalOrderInterface.itemNumber.setText("Not Exist");
                } else {
                    NormalOrderInterface.itemNumber.setText(itemNumber);
                }
            }

            @Override
            public void removeUpdate(DocumentEvent documentEvent) {
                String itemName = itemNameText.getText().trim();
                String itemNumber = BakeShopSystem.checkItemNumber(itemName);
                if (itemNumber == null) {
                    NormalOrderInterface.itemNumber.setText("Not Exist");
                } else {
                    NormalOrderInterface.itemNumber.setText(itemNumber);
                }
            }

            @Override
            public void changedUpdate(DocumentEvent documentEvent) {
                String itemName = itemNameText.getText().trim();
                String itemNumber = BakeShopSystem.checkItemNumber(itemName);
                if (itemNumber == null) {
                    NormalOrderInterface.itemNumber.setText("Not Exist");
                } else {
                    NormalOrderInterface.itemNumber.setText(itemNumber);
                }
            }
        });
        panel.add(itemNameText);

        itemNumberLabel = new JLabel("Item number:");
        itemNumberLabel.setForeground(Color.decode("#0abab5"));
        itemNumberLabel.setBounds(660, 160, 200, 50);
        panel.add(itemNumberLabel);

        itemNumber = new JLabel();
        itemNumber.setForeground(Color.decode("#0abab5"));
        itemNumber.setBounds(770, 160, 200, 50);
        panel.add(itemNumber);

        // Add button
        addButton = new JButton("Add Item");
        addButton.setBounds(860, 170, 100, 30);
        setButtonBorder(addButton);
        setMouseMove(addButton);
        addButton.addActionListener(new AddListener());
        panel.add(addButton);

        // Display the added items
        items = new ArrayList<>();
        items.add("Added items:");
        itemList = new JList<>(items.toArray(new String[items.size()]));
        itemScroll = new JScrollPane(itemList);
        itemScroll.setBounds(250, 300, 400, 100);
        itemScroll.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        panel.add(itemScroll);

        priceLabel = new JLabel("Total price:");
        priceLabel.setBounds(660, 350, 200, 50);
        priceLabel.setForeground(Color.decode("#0abab5"));
        panel.add(priceLabel);

        totalPriceLabel = new JLabel("0");
        totalPriceLabel.setBounds(750, 350, 200, 50);
        totalPriceLabel.setForeground(Color.decode("#0abab5"));
        panel.add(totalPriceLabel);

        createButton = new JButton("Create Order");
        createButton.setBounds(860, 360, 100, 30);
        createButton.addActionListener(new CreateListener());
        setButtonBorder(createButton);
        setMouseMove(createButton);
        panel.add(createButton);

        time = new JTextField();
        time.setBounds(800,500,200,50);
        time.setForeground(Color.GRAY);
        time.setBorder(null);
        time.addActionListener(new TimeActionListener());
        panel.add(time);

        storeLabel = new JLabel("Store ID: " + BakeShopSystem.getStoreID());
        storeLabel.setBounds(700,500,200,50);
        storeLabel.setForeground(Color.GRAY);
        panel.add(storeLabel);
    }

    /**
     * method name: menuGui
     * description:
     * param: []
     * @return void
     */
    public static void menuGui() {
        // Main Icon
        shopButton = new JButton(new ImageIcon("src/ICON/shopIN.png"));
        shopButton.setBounds(0, 0, 60, 60);
        panel.add(shopButton);

        displayButton = new JButton(new ImageIcon("src/ICON/display.png"));
        displayButton.setBounds(0, 60, 60, 60);
        displayButton.addActionListener(new OrderDisplayListener());
        panel.add(displayButton);

        starButton = new JButton(new ImageIcon("src/ICON/star.png"));
        starButton.setBounds(0, 120, 60, 60);
        starButton.addActionListener(new InventoryListener());
        panel.add(starButton);

        settingButton = new JButton(new ImageIcon("src/ICON/setting.png"));
        settingButton.setBounds(0, 520, 60, 60);
        settingButton.addActionListener(new SettingListener());
        panel.add(settingButton);
    }

    static class TimeActionListener implements ActionListener {
        /**
         * method name: TimeActionListener
         * description:
         * param: []
         * @return
         */
        public TimeActionListener() {
            javax.swing.Timer t = new javax.swing.Timer(1000,this);
            t.start();
        }

        /**
         * method name: actionPerformed
         * description:
         * param: [actionEvent]
         * @return void
         */
        @Override
        public void actionPerformed(ActionEvent actionEvent) {
            SimpleDateFormat timeForm = new SimpleDateFormat("dd/MM/YYY hh:mm:ss");
            time.setText(timeForm.format(new java.util.Date()).toString());
        }
    }

    static class OrderDisplayListener implements ActionListener {
        /**
         * method name: actionPerformed
         * description:
         * param: [actionEvent]
         * @return void
         */
        @Override
        public void actionPerformed(ActionEvent actionEvent) {
            new OrderDisplayInterface();
            frame.setVisible(false);
        }
    }

    static class InventoryListener implements ActionListener {
        /**
         * method name: actionPerformed
         * description:
         * param: [actionEvent]
         * @return void
         */
        @Override
        public void actionPerformed(ActionEvent actionEvent) {
            new InventoryInterface();
            frame.setVisible(false);
        }
    }

    static class SettingListener implements ActionListener {
        /**
         * method name: actionPerformed
         * description:
         * param: [actionEvent]
         * @return void
         */
        @Override
        public void actionPerformed(ActionEvent actionEvent) {
            new SettingInterface();
            frame.setVisible(false);
        }
    }

    static class AdvancedOrderListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent actionEvent) {
            new AdvancedOrderInterface();
            frame.setVisible(false);
        }
    }

    static class AddListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent actionEvent) {
            String itemNumber = NormalOrderInterface.itemNumber.getText();
            if (itemNumber.equals("Not Exist") || itemNumber.equals("")) {
                JOptionPane.showMessageDialog(null, "You can not add none exist item!");
            } else {
                String item = itemNameText.getText();
                items.add(item);
                itemList.setListData(items.toArray(new String[items.size()]));
                totalPriceLabel.setText(String.valueOf(BakeShopSystem.getTotalPrice(items)));
            }
        }
    }

    static class CreateListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent actionEvent) {
            String custName = JOptionPane.showInputDialog("Please enter customer name!");

            // Check null case
            if (custName == null) {
                return;
            } else {
                custName = custName.trim();
            }

            if (!custName.equals("")) {
                HashMap<String, Integer> mapOfItems = new HashMap<>();
                ArrayList<String> list = items;
                list.remove(0);
                for (String item : list) {
                    if (!mapOfItems.containsKey(item)) {
                        mapOfItems.put(item, 1);
                    } else {
                        int number = mapOfItems.get(item) + 1;
                        mapOfItems.put(item, number);
                    }
                }

                ArrayList<String> itemAL = new ArrayList<>();
                ArrayList<String> quantityAL = new ArrayList<>();
                ArrayList<String> priceAL = new ArrayList<>();

                //Create order
                for (String key : mapOfItems.keySet()) {
                    itemAL.add(key);
                    quantityAL.add(String.valueOf(mapOfItems.get(key)));
                    priceAL.add(String.valueOf(BakeShopSystem.checkItemPrice(key) * mapOfItems.get(key)));
                }

                String[] itemL = new String[itemAL.size()];
                String[] quantityL = new String[itemAL.size()];
                String[] priceL = new String[itemAL.size()];

                for (int i = 0; i < itemAL.size(); i++) {
                    itemL[i] = itemAL.get(i);
                    quantityL[i] = quantityAL.get(i);
                    priceL[i] = priceAL.get(i);
                }

                Date datetime = new Date();
                SimpleDateFormat dateForm = new SimpleDateFormat("dd/MM/YYYY");
                SimpleDateFormat timeForm = new SimpleDateFormat("HH:mm");
                String date = dateForm.format(datetime);
                String time = timeForm.format(datetime);

                // create order
                String orderID = OrderDisplaySystem.generateOrderID();
                OrderDisplaySystem.createOrder(BakeShopSystem.getStoreID(), orderID, BakeShopSystem.getStaffID(),
                        itemL, quantityL, priceL, String.valueOf(BakeShopSystem.getTotalPrice(itemAL)), date, time, custName, "confirmed", "");
                // write order
                String allItem = "";
                for (int i = 0; i < (itemL.length); i++){
                    allItem = allItem + itemL[i] + ",  ";
                }
                String allItems = allItem.substring(0, allItem.length()-3);

                String allQuantity = "";
                for (int j = 0; j < (quantityL.length); j++){
                    allQuantity = allQuantity + quantityL[j] + ", ";
                }
                String allQuantitys = allQuantity.substring(0, allQuantity.length()-2);
                //System.out.println(allQuantitys);

                String allPrice = "";
                for (int k = 0; k < (priceL.length); k++){
                    allPrice = allPrice + priceL[k] + "|";
                }
                String allPrices = allPrice.substring(0, allPrice.length()-1);

                OrderDisplaySystem.writeOrder(BakeShopSystem.getStoreID(), orderID, BakeShopSystem.getStaffID(), allItems, allQuantitys,
                        allPrices, String.valueOf(BakeShopSystem.getTotalPrice(itemAL)), date, time, custName,
                        "confirmed", "");

                new OrderDisplayInterface();
                frame.setVisible(false);
            } else {
                JOptionPane.showMessageDialog(null, "No customer name entered！");
            }

        }
    }

    public Map<Item, Integer> getMapOfItems() {
        return mapOfItems;
    }

    public void setMapOfItems(Map<Item, Integer> mapOfItems) {
        this.mapOfItems = mapOfItems;
    }

    public String getUserIDOrEmail() {
        return userIDOrEmail;
    }

    public void setUserIDOrEmail(String userIDOrEmail) {
        this.userIDOrEmail = userIDOrEmail;
    }

    public void displayNumberInputWindow() {

    }

    public int enterItemNumber() {
        return 0;
    }

    public void displayAddedItems() {

    }

    public int enterRemoveNumber() {
        return 0;
    }

    public void displayRemoveNumberError() {

    }

    public void displayOrderCreatingDetails() {

    }

    public String enterCustName() {
        return null;
    }

    public void addOrder() {

    }

    /**
     * method name: main
     * description:
     * param: [args]
     * @return void
     */
    public static void main(String[] args) {
        Gui();
        menuGui();
        orderGui();
        frame.setVisible(true);
    }
}
