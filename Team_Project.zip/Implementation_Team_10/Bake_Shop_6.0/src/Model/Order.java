package Model;

import java.util.Date;
import java.util.Map;

public class Order {
    private String storeID;
    private String orderID;
    private String staffID;
    private String[] items;
    private String[] quantity;
    private String[] price;
    private String totalAmount;
    private String date;
    private String time;
    private String custName;
    private String orderStatus;
    private Map<Item, Integer> mapOfItem;

    /**
     * constructor name: Order
     * description:
     * param: [storeID, orderID, staffID, items, quantity, price, totalAmount, date, time, custName, orderStatus]
     * @return
     */
    public Order(String storeID, String orderID, String staffID, String[] items, String[] quantity, String[] price, String totalAmount, String date, String time, String custName, String orderStatus) {
        this.storeID = storeID;
        this.orderID = orderID;
        this.staffID = staffID;
        this.items = items;
        this.quantity = quantity;
        this.price = price;
        this.date = date;
        this.time = time;
        this.orderStatus = orderStatus;
        this.custName = custName;
        this.totalAmount = totalAmount;
    }

    /**
     * method name: setStoreID
     * description:
     * param: [storeID]
     * @return void
     */
    public void setStoreID(String storeID) {
        this.storeID = storeID;
    }

    /**
     * method name: setOrderID
     * description:
     * param: [orderID]
     * @return void
     */
    public void setOrderID(String orderID) {
        this.orderID = orderID;
    }

    /**
     * method name: setStaffID
     * description:
     * param: [staffID]
     * @return void
     */
    public void setStaffID(String staffID) {
        this.staffID = staffID;
    }

    public void setItems(String[] items) {
        this.items = items;
    }

    public void setQuantity(String[] quantity) {
        this.quantity = quantity;
    }

    /**
     * method name: setPrice
     * description:
     * param: [price]
     * @return void
     */
    public void setPrice(String[] price) {
        this.price = price;
    }

    public void setTotalAmount(String totalAmount) {
        this.totalAmount = totalAmount;
    }

    /**
     * method name: setDate
     * description:
     * param: [date]
     * @return void
     */
    public void setDate(String date) {
        this.date = date;
    }

    /**
     * method name: setTime
     * description:
     * param: [time]
     * @return void
     */
    public void setTime(String time) {
        this.time = time;
    }

    public void setCustName(String custName) {
        this.custName = custName;
    }

    public void setOrderStatus(String orderStatus) {
        this.orderStatus = orderStatus;
    }

    public void setMapOfItem(Map<Item, Integer> mapOfItem) {
        this.mapOfItem = mapOfItem;
    }

    /**
     * method name: getStoreID
     * description:
     * param: []
     * @return java.lang.String
     */
    public String getStoreID() {
        return storeID;
    }

    /**
     * method name: getOrderID
     * description:
     * param: []
     * @return java.lang.String
     */
    public String getOrderID() {
        return orderID;
    }

    /**
     * method name: getStaffID
     * description:
     * param: []
     * @return java.lang.String
     */
    public String getStaffID() {
        return staffID;
    }

    /**
     * method name: getItems
     * description:
     * param: []
     * @return java.lang.String[]
     */
    public String[] getItems() {
        return items;
    }

    /**
     * method name: getQuantity
     * description:
     * param: []
     * @return java.lang.String[]
     */
    public String[] getQuantity() {
        return quantity;
    }

    /**
     * method name: getPrice
     * description:
     * param: []
     * @return java.lang.String[]
     */
    public String[] getPrice() {
        return price;
    }

    /**
     * method name: getTotalAmount
     * description:
     * param: []
     * @return java.lang.String
     */
    public String getTotalAmount() {
        return totalAmount;
    }

    /**
     * method name: getDate
     * description:
     * param: []
     * @return java.lang.String
     */
    public String getDate() {
        return date;
    }

    /**
     * method name: getTime
     * description:
     * param: []
     * @return java.lang.String
     */
    public String getTime() {
        return time;
    }

    /**
     * method name: getCustName
     * description:
     * param: []
     * @return java.lang.String
     */
    public String getCustName() {
        return custName;
    }

    public String getOrderStatus() {
        return orderStatus;
    }

    public Map<Item, Integer> getMapOfItem() {
        return mapOfItem;
    }

    public boolean validateAuthorityProcess() {
        return false;
    }

    @Override
    /**
     * method name: toString
     * description:
     * param: []
     * @return java.lang.String
     */
    public String toString() {
        return "Order{" +
                "storeID='" + storeID + '\'' +
                ", orderID='" + orderID + '\'' +
                ", staffID='" + staffID + '\'' +
                ", items='" + items + '\'' +
                ", quantity='" + quantity + '\'' +
                ", price='" + price + '\'' +
                ", totalAmount='" + totalAmount + '\'' +
                ", date='" + date + '\'' +
                ", time='" + time + '\'' +
                ", custName='" + custName + '\'' +
                ", orderStatus='" + orderStatus + '\'' +
                ", mapOfItem=" + mapOfItem +
                '}';
    }
}