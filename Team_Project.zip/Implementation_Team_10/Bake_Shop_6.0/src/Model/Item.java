package Model;

public class Item{
    private String storeID;
    private String itemNumber;
    private String itemName;
    private float price;

    /**
     * constructor name: Item
     * description:
     * param: [storeID, itemNumber, itemName, price]
     * @return
     */
    public Item(String storeID, String itemNumber, String itemName, float price) {
        this.storeID = storeID;
        this.itemNumber = itemNumber;
        this.itemName = itemName;
        this.price = price;
    }

    /**
     * method name: getStoreID
     * description:
     * param: []
     * @return java.lang.String
     */
    public String getStoreID() {
        return storeID;
    }

    /**
     * method name: setStoreID
     * description:
     * param: [storeID]
     * @return void
     */
    public void setStoreID(String storeID) {
        this.storeID = storeID;
    }

    /**
     * method name: getItemName
     * description:
     * param: []
     * @return java.lang.String
     */
    public String getItemName() {
        return itemName;
    }

    /**
     * method name: getItemNumber
     * description:
     * param: []
     * @return java.lang.String
     */
    public String getItemNumber() {
        return itemNumber;
    }

    /**
     * method name: getPrice
     * description:
     * param: []
     * @return float
     */
    public float getPrice() {
        return price;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public void setItemNumber(String itemNumber) {
        this.itemNumber = itemNumber;
    }

    /**
     * method name: setPrice
     * description:
     * param: [price]
     * @return void
     */
    public void setPrice(float price) {
        this.price = price;
    }

    @Override
    /**
     * method name: toString
     * description:
     * param: []
     * @return java.lang.String
     */
    public String toString() {
        return "Item{" +
                "storeID='" + storeID + '\'' +
                ", itemNumber='" + itemNumber + '\'' +
                ", itemName='" + itemName + '\'' +
                ", price=" + price +
                '}';
    }
}