package Model;

import java.util.ArrayList;

public class Store{
    private String storeID;
    private String street;
    private String city;
    private String suburb;
    private String postal;
    private String phone;
    private Inventory inventory;
    private ArrayList<Employee> listOfEmployee;
    private ArrayList<Order> listOfOrder;

    /**
     * method name: Store
     * description:
     * param: [storeID, street, city, suburb, postal, phone]
     * @return
     */
    public Store(String storeID, String street, String city, String suburb, String postal, String phone) {
        this.storeID = storeID;
        this.street = street;
        this.city = city;
        this.suburb = suburb;
        this.postal = postal;
        this.phone = phone;

    }


    /**
     * method name: getStoreID
     * description:
     * param: []
     * @return String
     */
    public String getStoreID() {
        return storeID;
    }

    /**
     * method name: getStreet
     * description:
     * param: []
     * @return String
     */
    public String getStreet() {
        return street;
    }

    /**
     * method name: getCity
     * description:
     * param: []
     * @return String
     */
    public String getCity() {
        return city;
    }

    /**
     * method name: getSuburb
     * description:
     * param: []
     * @return String
     */
    public String getSuburb() {
        return suburb;
    }


    /**
     * method name: getPostal
     * description:
     * param: []
     * @return String
     */
    public String getPostal() {
        return postal;
    }

    /**
     * method name: getPhone
     * description:
     * param: []
     * @return String
     */
    public String getPhone() {
        return phone;
    }

    /**
     * method name: getInventory
     * description:
     * param: []
     * @return Inventory
     */
    public Inventory getInventory() {
        return inventory;
    }

    /**
     * method name: getEmployeeFromStore
     * description:
     * param: [index]
     * @return Employee
     */
    public Employee getEmployeeFromStore(int index) {
        return null;
    }

    /**
     * method name: getOrderFromStore
     * description:
     * param: [index]
     * @return Order
     */
    public Order getOrderFromStore(int index) {
        return null;
    }

    /**
     * method name: setStoreID
     * description:
     * param: [storeID]
     * @return void
     */
    public void setStoreID(String storeID) {
        this.storeID = storeID;
    }

    /**
     * method name: setStreet
     * description:
     * param: [street]
     * @return void
     */
    public void setStreet(String street) {
        this.street = street;
    }

    /**
     * method name: setCity
     * description:
     * param: [city]
     * @return void
     */
    public void setCity(String city) {
        this.city = city;
    }

    /**
     * method name: setSuburb
     * description:
     * param: [suburb]
     * @return void
     */
    public void setSuburb(String suburb) {
        this.suburb = suburb;
    }

    /**
     * method name: setPostal
     * description:
     * param: [postal]
     * @return void
     */
    public void setPostal(String postal) {
        this.postal = postal;
    }

    /**
     * method name: setPhone
     * description:
     * param: [phone]
     * @return void
     */
    public void setPhone(String phone) {
        this.phone = phone;
    }

    /**
     * method name: setInventory
     * description:
     * param: [inventory]
     * @return void
     */
    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }

    /**
     * method name: setListOfEmployee
     * description:
     * param: [listOfEmployee]
     * @return void
     */
    public void setListOfEmployee(ArrayList<Employee> listOfEmployee) {
        this.listOfEmployee = listOfEmployee;
    }

    /**
     * method name: setListOfOrder
     * description:
     * param: [listOfOrder]
     * @return void
     */
    public void setListOfOrder(ArrayList<Order> listOfOrder) {
        this.listOfOrder = listOfOrder;
    }

    /**
     * method name: checkUserIDOrEmail
     * description:
     * param: [ID]
     * @return boolean
     */
    public boolean checkUserIDOrEmail(String ID) {
        return false;
    }

    /**
     * method name: checkPassword
     * description:
     * param: [password]
     * @return boolean
     */
    public boolean checkPassword(String password) {
        return false;
    }

    public float calculateRevenue() {
        return 0;
    }

    /**
     * method name: calculateSaleNumber
     * description:
     * param: []
     * @return int[]
     */
    public int[] calculateSaleNumber() {
        return null;
    }

    /**
     * method name: calculateNumberOfCoffee
     * description:
     * param: []
     * @return int
     */
    public int calculateNumberOfCoffee() {
        return 0;
    }

    /**
     * method name: calculateNumberOfFood
     * description:
     * param: []
     * @return int
     */
    public int calculateNumberOfFood() {
        return 0;
    }

    /**
     * method name: calculateNumberOfBeans
     * description:
     * param: []
     * @return int
     */
    public int calculateNumberOfBeans() {
        return 0;
    }

    /**
     * method name: calculateMostSaleType
     * description:
     * param: []
     * @return String[]
     */
    public String[] calculateMostSaleType() {
        return null;
    }

    /**
     * method name: calculateTypeOfCoffee
     * description:
     * param: []
     * @return String
     */
    public String calculateTypeOfCoffee() {
        return null;
    }

    /**
     * method name: calculateTypeOfFood
     * description:
     * param: []
     * @return String
     */
    public String calculateTypeOfFood() {
        return null;
    }

    /**
     * method name: calculateTotalSale
     * description:
     * param: []
     * @return float
     */
    public float calculateTotalSale() {
        return 0;
    }

    /**
     * method name: toString
     * description:
     * param: []
     * @return String
     */
    @Override
    public String toString() {
        return "Store{" +
                "storeID='" + storeID + '\'' +
                ", street='" + street + '\'' +
                ", city='" + city + '\'' +
                ", suburb='" + suburb + '\'' +
                ", postal='" + postal + '\'' +
                ", phone='" + phone + '\'' +
                ", inventory=" + inventory +
                '}';
    }
}