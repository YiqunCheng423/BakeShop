package Model;

public class Report {

    public Report() {
    }

    public String generateMonthReport(){
        return null;
    }

    public String generateWeekReport(){
        return null;
    }
}
