package Model;

import java.util.Map;

public class Inventory{
    private String storeID;
    private String itemID;
    private String nameOfItem;
    private String quantity;
    private String dateInventoryAdded;
    private Map<Item, Integer> mapOfItems;


    /**
     * constructor name: Inventory
     * description:
     * param: [storeID, itemID, nameOfItem, quantity, dateInventoryAdded]
     * @return
     */
    public Inventory(String storeID, String itemID, String nameOfItem, String quantity, String dateInventoryAdded) {
        this.storeID = storeID;
        this.itemID = itemID;
        this.nameOfItem = nameOfItem;
        this.quantity = quantity;
        this.dateInventoryAdded = dateInventoryAdded;
    }

    public Map<Item, Integer> getMapOfItems() {
        return mapOfItems;
    }

    /**
     * method name: getStoreID
     * description:
     * param: []
     * @return java.lang.String
     */
    public String getStoreID() {
        return storeID;
    }

    public String getItemID() {
        return itemID;
    }

    public String getNameOfItem() {
        return nameOfItem;
    }

    public String getQuantity() {
        return quantity;
    }

    public String getDateInventoryAdded() {
        return dateInventoryAdded;
    }

    public void setMapOfItems(Map<Item, Integer> mapOfItems) {
        this.mapOfItems = mapOfItems;
    }

    /**
     * method name: setStoreID
     * description:
     * param: [storeID]
     * @return void
     */
    public void setStoreID(String storeID) {
        this.storeID = storeID;
    }

    public void setItemID(String itemID) {
        this.itemID = itemID;
    }

    public void setNameOfItem(String nameOfItem) {
        this.nameOfItem = nameOfItem;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    /**
     * method name: setDateInventoryAdded
     * description:
     * param: [dateInventoryAdded]
     * @return void
     */
    public void setDateInventoryAdded(String dateInventoryAdded) {
        this.dateInventoryAdded = dateInventoryAdded;
    }
}