package Model;

public class Manager extends Employee {
    private String authority;

    /**
     * constructor name: Manager
     * description:
     * param: [staffID, name, email, password, TFN, street, city, state, postal, phone, storeID, authority]
     * @return
     */
    public Manager(String staffID, String name, String email, String password, String TFN, String street, String city, String state, String postal, String phone, String storeID, String authority) {
        super(staffID, name, email, password, TFN, street, city, state, postal, phone, storeID);
        this.authority = authority;
    }

    public String getAuthority() {
        return authority;
    }

    public void setAuthority(String authority) {
        this.authority = authority;
    }

    @Override
    /**
     * method name: toString
     * description:
     * param: []
     * @return java.lang.String
     */
    public String toString() {
        return "Manager{" +
                "authority='" + authority + '\'' +
                '}';
    }
}
