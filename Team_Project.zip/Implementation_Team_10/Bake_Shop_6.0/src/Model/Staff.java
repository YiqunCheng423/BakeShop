package Model;

public class Staff extends Employee {
    private String authority;

    /**
     * method name: Staff
     * description:
     * param: [staffID, name, email, password, TFN, street, city, state, postal, phone, storeID, authority]
     * @return
     */
    public Staff(String staffID, String name, String email, String password, String TFN, String street, String city, String state, String postal, String phone, String storeID, String authority) {
        super(staffID, name, email, password, TFN, street, city, state, postal, phone, storeID);
        this.authority = authority;
    }

    /**
     * method name: getAuthority
     * description:
     * param: []
     * @return String
     */
    public String getAuthority() {
        return authority;
    }

    /**
     * method name: setAuthority
     * description:
     * param: [authority]
     * @return void
     */
    public void setAuthority(String authority) {
        this.authority = authority;
    }

    /**
     * method name: toString
     * description:
     * param: []
     * @return String
     */
    @Override
    public String toString() {
        return "Staff{" +
                "authority='" + authority + '\'' +
                '}';
    }
}
