package Model;

public class AdvancedOrder extends Order {

    private String custPhone;

    /**
     * constructor name: AdvancedOrder
     * description:
     * param: [storeID, orderID, staffID, items, quantity, price, totalAmount, date, time, custName, orderStatus, custPhone]
     * @return
     */
    public AdvancedOrder(String storeID, String orderID, String staffID, String[] items, String[] quantity, String[] price, String totalAmount, String date, String time, String custName, String orderStatus, String custPhone) {
        super(storeID, orderID, staffID, items, quantity, price, totalAmount, date, time, custName, orderStatus);
        this.custPhone = custPhone;
    }

    /**
     * method name: getCustPhone
     * description:
     * param: []
     * @return java.lang.String
     */
    public String getCustPhone() {
        return custPhone;
    }

    /**
     * method name: setCustPhone
     * description:
     * param: [custPhone]
     * @return void
     */
    public void setCustPhone(String custPhone) {
        this.custPhone = custPhone;
    }
}
