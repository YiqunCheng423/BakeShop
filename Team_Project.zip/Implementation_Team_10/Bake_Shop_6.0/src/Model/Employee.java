package Model;

public class Employee {

    private String staffID;
    private String name;
    private String email;
    private String password;
    private String TFN;
    private String street;
    private String city;
    private String state;
    private String postal;
    private String phone;
    private String storeID;

    /**
     * constructor name: Employee
     * description:
     * param: [staffID, name, email, password, TFN, street, city, state, postal, phone, storeID]
     * @return
     */
    public Employee(String staffID, String name, String email, String password, String TFN, String street, String city, String state, String postal, String phone, String storeID) {
        this.staffID = staffID;
        this.name = name;
        this.email = email;
        this.password = password;
        this.TFN = TFN;
        this.street = street;
        this.city = city;
        this.state = state;
        this.postal = postal;
        this.phone = phone;
        this.storeID = storeID;
    }

    /**
     * method name: getStaffID
     * description:
     * param: []
     * @return java.lang.String
     */
    public String getStaffID() {
        return staffID;
    }

    /**
     * method name: setStaffID
     * description:
     * param: [staffID]
     * @return void
     */
    public void setStaffID(String staffID) {
        this.staffID = staffID;
    }

    /**
     * method name: getName
     * description:
     * param: []
     * @return java.lang.String
     */
    public String getName() {
        return name;
    }

    /**
     * method name: setName
     * description:
     * param: [name]
     * @return void
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * method name: getEmail
     * description:
     * param: []
     * @return java.lang.String
     */
    public String getEmail() {
        return email;
    }

    /**
     * method name: setEmail
     * description:
     * param: [email]
     * @return void
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * method name: getPassword
     * description:
     * param: []
     * @return java.lang.String
     */
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getTFN() {
        return TFN;
    }

    public void setTFN(String TFN) {
        this.TFN = TFN;
    }

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    /**
     * method name: getState
     * description:
     * param: []
     * @return java.lang.String
     */
    public String getState() {
        return state;
    }

    /**
     * method name: setState
     * description:
     * param: [state]
     * @return void
     */
    public void setState(String state) {
        this.state = state;
    }

    /**
     * method name: getPostal
     * description:
     * param: []
     * @return java.lang.String
     */
    public String getPostal() {
        return postal;
    }

    /**
     * method name: setPostal
     * description:
     * param: [postal]
     * @return void
     */
    public void setPostal(String postal) {
        this.postal = postal;
    }

    /**
     * method name: getPhone
     * description:
     * param: []
     * @return java.lang.String
     */
    public String getPhone() {
        return phone;
    }

    /**
     * method name: setPhone
     * description:
     * param: [phone]
     * @return void
     */
    public void setPhone(String phone) {
        this.phone = phone;
    }

    public boolean validateAuthorityProcess(){
        return false;
    }

    /**
     * method name: getStoreID
     * description:
     * param: []
     * @return java.lang.String
     */
    public String getStoreID() {
        return storeID;
    }

    /**
     * method name: setStoreID
     * description:
     * param: [storeID]
     * @return void
     */
    public void setStoreID(String storeID) {
        this.storeID = storeID;
    }
}
